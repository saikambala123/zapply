/**
 * ZAPPLY BACKGROUND SERVICE WORKER
 * --------------------------------
 * Owns the bearer token and the cached session. Content scripts never talk to
 * the API directly — they ask the worker, which keeps credentials out of pages
 * and lets one fetch serve every tab.
 */

/**
 * The deployment this extension talks to.
 *
 * This used to default to http://localhost:3000, which meant a published build
 * pointed every fresh install at a server on the user's own machine: pairing
 * failed with "Can't reach Zapply" until they found the API field in the popup
 * and retyped the URL. `npm run ext:build` rewrites this line from
 * NEXT_PUBLIC_APP_URL, and the popup can still override it for local dev.
 */
const DEFAULT_API = "https://zapply.vercel.app"; /* build:api-base */
// Short, because this is how long a settings change in the dashboard takes to
// reach the extension. Anything longer and toggles look broken.
const CACHE_TTL_MS = 60 * 1000;
// Beyond this we block on the network rather than serve a stale profile.
const STALE_MAX_MS = 30 * 60 * 1000;
// Floor between background refreshes triggered by tab activity.
const REFRESH_THROTTLE_MS = 60 * 1000;
let refreshing = null;
let lastRefreshAt = 0;

/* ------------------------------------------------------------------ */
/*  Storage helpers                                                    */
/* ------------------------------------------------------------------ */

const storageCall = (method, value) => new Promise((resolve, reject) => {
  chrome.storage.local[method](value, (result) => {
    const error = chrome.runtime.lastError;
    if (error) reject(new Error(error.message || "Could not save extension data."));
    else resolve(result);
  });
});
const store = {
  get: async (keys) => (await storageCall("get", keys)) || {},
  set: (obj) => storageCall("set", obj),
  remove: (keys) => storageCall("remove", keys),
};

async function apiBase() {
  const { apiBase } = await store.get("apiBase");
  return (apiBase || DEFAULT_API).replace(/\/+$/, "");
}

async function authHeaders() {
  const { token } = await store.get("token");
  return token ? { Authorization: `Bearer ${token}` } : {};
}

/* ------------------------------------------------------------------ */
/*  API                                                                */
/* ------------------------------------------------------------------ */

async function api(path, options = {}) {
  const base = await apiBase();
  const headers = {
    "Content-Type": "application/json",
    ...(await authHeaders()),
    ...(options.headers ?? {}),
  };

  // Never let a dead network connection leave the popup/content script waiting
  // forever. Serverless deployments can occasionally stall before returning a
  // response; the extension should fail fast and keep the form usable.
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15_000);

  try {
    const res = await fetch(`${base}${path}`, { ...options, headers, signal: options.signal ?? controller.signal });
    const json = await res.json().catch(() => ({}));

    if (res.status === 401) {
      await store.remove(["token", "session", "sessionAt"]);
      setBadge("!", "#E5484D");
      return { ok: false, error: "Your Zapply session expired. Pair again from the dashboard." };
    }
    if (!res.ok) return { ok: false, error: json.error || `Request failed (${res.status})` };
    return { ok: true, data: json.data };
  } catch (err) {
    const message = err?.name === "AbortError"
      ? "Zapply took too long to respond. Check your connection and try again."
      : "Can't reach Zapply. Check your connection and try again.";
    return { ok: false, error: message };
  } finally {
    clearTimeout(timeout);
  }
}

/* ------------------------------------------------------------------ */
/*  Session cache                                                      */
/* ------------------------------------------------------------------ */

/** Bootstrap payload, cached so a burst of tabs costs one request. */
async function getSession({ force = false } = {}) {
  const { session, sessionAt, token, selectedProfileId } = await store.get(["session", "sessionAt", "token", "selectedProfileId"]);
  if (!token) return null;

  const age = sessionAt ? Date.now() - sessionAt : Infinity;

  if (session && age < CACHE_TTL_MS && !force) return session;

  // Stale-while-revalidate: an autofill shouldn't wait on the network, but the
  // cache also shouldn't go stale for minutes. Serve what we have and refresh
  // behind it, so the next fill uses current settings and saved answers.
  if (session && age < STALE_MAX_MS && !force) {
    refreshSession();
    return session;
  }

  const res = await api("/api/extension/bootstrap");
  if (!res.ok) {
    if (force) throw new Error(res.error || "Could not refresh saved answers.");
    return session ?? null;
  }
  if (!Array.isArray(res.data?.profiles) || !Array.isArray(res.data?.responses)) {
    throw new Error("Zapply returned an incomplete sync response. Please update the portal and try again.");
  }

  const active =
    res.data.profiles.find((p) => p._id === selectedProfileId) ??
    res.data.profiles.find((p) => p._id === res.data.activeProfileId) ??
    res.data.profiles.find((p) => p.isDefault) ??
    res.data.profiles[0] ??
    null;

  const next = {
    user: res.data.user,
    premium: res.data.user?.premium ?? false,
    settings: res.data.settings ?? {},
    profiles: res.data.profiles ?? [],
    profile: active,
    responses: res.data.responses ?? [],
    syncedAt: res.data.syncedAt,
  };

  await store.set({ session: next, sessionAt: Date.now() });
  setBadge(next.profile ? "" : "!", next.profile ? "#00C2A8" : "#FFB020");
  return next;
}

/** Background refresh, deduped so ten tabs don't trigger ten fetches. */
function refreshSession() {
  if (refreshing) return refreshing;
  refreshing = getSession({ force: true })
    .catch(() => null)
    .finally(() => { refreshing = null; lastRefreshAt = Date.now(); });
  return refreshing;
}

/**
 * Refresh triggered by browsing activity rather than by a user action.
 *
 * `tabs.onActivated` fires on every tab switch, and it called the unthrottled
 * refresh — so a normal session of flicking between tabs fired a bootstrap
 * request each time, hammering the API for a payload that changes rarely.
 */
function maybeRefreshSession() {
  if (refreshing) return;
  if (Date.now() - lastRefreshAt < REFRESH_THROTTLE_MS) return;
  refreshSession();
}

/**
 * The badge is the only thing that tells the applicant an answer is waiting.
 *
 * It counts both buckets: answers held after an edit and answers already queued
 * for sync. Without it, held answers sat in storage with nothing anywhere on
 * screen to say so — the applicant had to think to open the popup.
 */
async function refreshBadge() {
  try {
    const { heldAnswers, pendingResponses } = await store.get(["heldAnswers", "pendingResponses"]);
    const total = (heldAnswers?.length ?? 0) + (pendingResponses?.length ?? 0);
    setBadge(total ? String(Math.min(99, total)) : "", (heldAnswers?.length ?? 0) ? "#FFB020" : "#5B2AD6");
  } catch {}
}

function setBadge(text, color = "#5B2AD6") {
  chrome.action.setBadgeText({ text });
  if (text) chrome.action.setBadgeBackgroundColor({ color });
}

// Serialize local answer mutations, but leave network waits outside the lock
// so a new edit during an upload is captured immediately.
let answerMutation = Promise.resolve();
function editAnswers(fn) {
  const task = answerMutation.then(fn);
  answerMutation = task.catch(() => {});
  return task;
}

async function promoteHeld(questions) {
  return editAnswers(async () => {
    const { heldAnswers = [], pendingResponses = [] } = await store.get(["heldAnswers", "pendingResponses"]);
    const wanted = questions?.length ? new Set(questions.map(queueKey)) : null;
    const moving = heldAnswers.filter((r) => !wanted || wanted.has(queueKey(r.question)));
    const keeping = heldAnswers.filter((r) => wanted && !wanted.has(queueKey(r.question)));
    const merged = new Map(pendingResponses.map((r) => [queueKey(r.question), r]));
    for (const r of moving) merged.set(queueKey(r.question), { ...r, queuedAt: Date.now() });
    await store.set({ heldAnswers: keeping, pendingResponses: Array.from(merged.values()) });
    return moving.length;
  });
}

const answerRevision = (r) => JSON.stringify([r.question, r.answer, r.inputType, r.options, r.domain, r.queuedAt]);
const uploadAnswer = (r) => ({
  question: String(r.question ?? "").trim().slice(0, 2000),
  answer: String(r.answer ?? "").trim().slice(0, 10000),
  inputType: String(r.inputType || "text").slice(0, 40),
  options: Array.isArray(r.options) ? r.options.slice(0, 100).map((v) => String(v).slice(0, 500)) : [],
  ...(r.ats ? { ats: String(r.ats).slice(0, 60) } : {}),
  ...(r.domain ? { domain: String(r.domain).slice(0, 300) } : {}),
});

async function pushQueue() {
  const { pendingResponses = [], token } = await store.get(["pendingResponses", "token"]);
  if (!token) return { ok: false, error: "Pair the extension from your dashboard first.", pushed: 0 };
  const responses = [...new Map(pendingResponses.map((r) => [queueKey(r.question), r])).values()];
  let pushed = 0;
  let failure = null;
  // The endpoint accepts at most 200; small batches also fit serverless limits.
  for (let start = 0; start < responses.length; start += 100) {
    const batch = responses.slice(start, start + 100);
    const valid = batch.filter((r) => String(r.question ?? "").length <= 2000 && String(r.answer ?? "").length <= 10000);
    if (!valid.length) { failure = "Some answers exceed the supported length and remain pending for review."; continue; }
    const res = await api("/api/extension/sync", { method: "POST", body: JSON.stringify({ responses: valid.map(uploadAnswer) }) });
    if (!res.ok) { failure = res.error; break; }
    const keys = Array.isArray(res.data?.savedKeys) ? res.data.savedKeys
      : Number(res.data?.responsesSaved) >= valid.length ? valid.map((r) => queueKey(r.question)) : [];
    const confirmed = new Set(keys);
    const sent = new Map(valid.filter((r) => confirmed.has(queueKey(r.question)))
      .map((r) => [queueKey(r.question), answerRevision(r)]));
    pushed += sent.size;
    await editAnswers(async () => {
      const { pendingResponses: now = [], session } = await store.get(["pendingResponses", "session"]);
      // A newer answer to the same question must survive the older upload.
      const remaining = now.filter((r) => sent.get(queueKey(r.question)) !== answerRevision(r));
      if (remaining.length) await store.set({ pendingResponses: remaining });
      else await store.remove("pendingResponses");
      // Keep confirmed answers usable if the following bootstrap request fails.
      if (session) {
        const merged = new Map((session.responses ?? []).map((r) => [queueKey(r.question), r]));
        for (const r of batch) if (sent.has(queueKey(r.question)))
          merged.set(queueKey(r.question), { ...uploadAnswer(r), normalizedKey: queueKey(r.question) });
        await store.set({ session: { ...session, responses: [...merged.values()] }, sessionAt: 0 });
      }
    });
    if (sent.size < batch.length) failure = "Some answers were not accepted. They remain pending; review their questions and retry Sync now.";
  }
  const { pendingResponses: remaining = [] } = await store.get("pendingResponses");
  return { ok: !failure, error: failure, pushed, remaining: remaining.length };
}

let syncing = null;
function syncPending() {
  if (syncing) return syncing;
  syncing = (async () => {
    await promoteHeld();
    const pushed = await pushQueue();
    let session = null, pullError = null;
    try { session = await getSession({ force: true }); }
    catch (err) { pullError = err.message; }
    await refreshBadge();
    const error = pushed.error || pullError || (!session ? "Pair the extension from your dashboard first." : null);
    return { ok: !error, error, data: {
      responsesSaved: pushed.pushed || 0, savedAnswers: session?.responses?.length ?? 0,
      pending: pushed.remaining ?? 0, syncedAt: session?.syncedAt,
    } };
  })().finally(() => { syncing = null; });
  return syncing;
}

function queueKey(question) {
  return String(question ?? "")
    .toLowerCase()
    .replace(/\(.*?\)/g, " ")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\b(please|kindly|the|a|an|your|you|us|our|this|that|is|are|do|does|did|of|to|for|in|on|at|we|and|or|if|will|would|can|could|may)\b/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 180);
}

/**
 * A dismissal identifies the answer that was turned down, not the question.
 *
 * Keyed on the question alone, "no thanks" to one bad capture silenced that
 * question for the life of the install.
 */
function dismissalKey(question, answer) {
  const q = queueKey(question);
  const a = String(answer ?? "").toLowerCase().replace(/\s+/g, " ").trim().slice(0, 120);
  return q ? `${q}::${a}` : "";
}

/** Dismissals lapse, so a rejected answer can never mute a question for good. */
const DISMISSAL_TTL_MS = 30 * 24 * 60 * 60 * 1000;

/**
 * Normalises the stored shape and drops anything expired.
 *
 * Older builds stored a bare array of question keys. Those are discarded rather
 * than migrated: they are precisely the permanent blocks that stopped answers
 * being captured, so an upgrade should clear them.
 */
function pruneDismissals(stored) {
  if (!stored || Array.isArray(stored)) return {};
  const cutoff = Date.now() - DISMISSAL_TTL_MS;
  const out = {};
  for (const [key, at] of Object.entries(stored)) {
    if (typeof at === "number" && at > cutoff) out[key] = at;
  }
  return out;
}

/**
 * The session as the content script should see it: the dashboard's saved
 * answers plus anything saved in this browser that has not reached the server.
 *
 * Autofill reads `session.responses`, and that list came only from a successful
 * bootstrap fetch. So an answer saved while offline — or while the sync request
 * was failing for any other reason — was invisible to the very next
 * application, which is the "I saved it and it still didn't fill" case. The
 * queue is merged in at read time only; it is never written back into the
 * cached session, or syncing it would upload the same answer twice.
 *
 * A local answer wins over the server's copy of the same question: it is the
 * newer of the two, being the edit that has not been uploaded yet.
 */
async function sessionForFill(session) {
  if (!session) return session;
  try {
    const { pendingResponses } = await store.get("pendingResponses");
    const queued = pendingResponses ?? [];
    if (!queued.length) return session;

    const merged = new Map(
      (session.responses ?? []).map((r) => [queueKey(r.question), r])
    );
    for (const r of queued) {
      const key = queueKey(r.question);
      if (!key || !String(r.answer ?? "").trim()) continue;
      merged.set(key, {
        ...(merged.get(key) ?? {}),
        question: r.question,
        answer: r.answer,
        inputType: r.inputType,
        options: r.options ?? [],
        normalizedKey: key,
        // Marked so nothing downstream mistakes it for a synced record.
        pendingLocal: true,
      });
    }
    return { ...session, responses: Array.from(merged.values()) };
  } catch {
    return session;
  }
}

/* ------------------------------------------------------------------ */
/*  Message router                                                     */
/* ------------------------------------------------------------------ */

chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  (async () => {
    switch (msg?.type) {
      /* --- pairing --- */
      case "ZAPPLY_PAIR": {
        const base = (msg.apiBase || (await apiBase())).replace(/\/+$/, "");
        await store.set({ apiBase: base });
        try {
          const res = await fetch(`${base}/api/extension/pair`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ code: msg.code }),
          });
          const json = await res.json();
          if (!res.ok) return respond({ ok: false, error: json.error });

          await store.set({ token: json.data.token, user: json.data.user });
          const session = await getSession({ force: true });
          return respond({ ok: true, data: { user: json.data.user, session } });
        } catch {
          return respond({ ok: false, error: "Couldn't reach that Zapply URL." });
        }
      }

      case "ZAPPLY_UNPAIR": {
        await store.remove(["token", "user", "session", "sessionAt", "pendingResponses", "heldAnswers", "dismissedAnswers", "selectedProfileId"]);
        setBadge("");
        return respond({ ok: true });
      }

      /* --- session --- */
      case "ZAPPLY_GET_SESSION": {
        const session = await getSession({ force: msg.force });
        if (!session) return respond({ ok: false, error: "not-connected" });
        return respond({ ok: true, data: await sessionForFill(session) });
      }

      case "ZAPPLY_SET_PROFILE": {
        const { session } = await store.get("session");
        if (!session) return respond({ ok: false, error: "not-connected" });
        const profile = session.profiles.find((p) => p._id === msg.profileId);
        if (profile) {
          session.profile = profile;
          await store.set({ session, selectedProfileId: profile._id });
        }
        return respond({ ok: true, data: session });
      }

      /* --- pending saved answers: local until the user clicks Sync now --- */
      /**
       * --- held answers: edited on a page, not yet saved ---
       *
       * These used to live in a plain Map inside the content script. A Workday
       * application navigates on every step, and each navigation tears the
       * content script down and takes the Map with it — so by the time the
       * applicant opened the popup there was nothing left to offer them, which
       * is why saving an answer appeared to do nothing at all.
       *
       * They live here now, in the same storage as the sync queue, and survive
       * navigation, reload and closing the tab. Nothing is uploaded from here:
       * saving moves an answer into `pendingResponses`, which is still only
       * sent on an explicit Sync.
       */
      case "ZAPPLY_HOLD_ANSWERS": return editAnswers(async () => {
        const { heldAnswers, dismissedAnswers } = await store.get(["heldAnswers", "dismissedAnswers"]);
        /**
         * A dismissal turns down *that answer*, not the question forever.
         *
         * Discarding used to record the question's key alone, and capture then
         * skipped that key from then on with no expiry. Pressing Clear once
         * therefore blacklisted every question in the list permanently: the
         * applicant answered the same question properly on the next
         * application, nothing was captured, nothing reached Saved Answers, and
         * from the outside the whole feature had simply stopped working. It was
         * unrecoverable without unpairing, because nothing in the UI mentions
         * this list.
         *
         * A dismissal is now keyed by question *and* answer, so the rejected
         * value stays rejected while a different answer to the same question is
         * captured normally. Entries also expire, so a stale "no" cannot silence
         * a question indefinitely.
         */
        const dismissed = pruneDismissals(dismissedAnswers);
        const merged = new Map((heldAnswers ?? []).map((r) => [queueKey(r.question), r]));
        for (const r of (msg.items ?? [])) {
          if (!r?.question || !String(r.answer ?? "").trim()) continue;
          const key = queueKey(r.question);
          if (!key) continue;
          if (dismissed[dismissalKey(r.question, r.answer)]) continue;
          merged.set(key, { ...r, heldAt: Date.now() });
        }
        const held = Array.from(merged.values()).slice(-200);
        await store.set({ heldAnswers: held, dismissedAnswers: dismissed });
        await refreshBadge();
        return respond({ ok: true, held: held.length });
      });

      case "ZAPPLY_GET_HELD": {
        const { heldAnswers } = await store.get("heldAnswers");
        return respond({ ok: true, data: { held: heldAnswers ?? [] } });
      }

      /** Move held answers into the sync queue. `questions` omitted = all. */
      case "ZAPPLY_SAVE_HELD": {
        const saved = await promoteHeld(msg.questions);
        await refreshBadge();
        return respond({ ok: true, saved, synced: false, uploaded: 0 });
      }

      case "ZAPPLY_DISCARD_HELD": return editAnswers(async () => {
        const { heldAnswers, dismissedAnswers } = await store.get(["heldAnswers", "dismissedAnswers"]);
        const held = heldAnswers ?? [];
        const wanted = msg.questions?.length ? new Set(msg.questions.map((q) => queueKey(q))) : null;
        const dropping = wanted ? held.filter((r) => wanted.has(queueKey(r.question))) : held;
        const keeping = wanted ? held.filter((r) => !wanted.has(queueKey(r.question))) : [];

        // Only the answer being dropped is remembered as unwanted. Recording
        // the bare question here is what silenced it on every later
        // application, including when the applicant answered it correctly.
        const dismissed = pruneDismissals(dismissedAnswers);
        const now = Date.now();
        dropping.forEach((r) => {
          const k = dismissalKey(r.question, r.answer);
          if (k) dismissed[k] = now;
        });

        const trimmed = Object.fromEntries(
          Object.entries(dismissed).sort((a, b) => b[1] - a[1]).slice(0, 500)
        );

        await store.set({ heldAnswers: keeping, dismissedAnswers: trimmed });
        await refreshBadge();
        return respond({ ok: true, dismissed: Object.keys(trimmed).length });
      });

      case "ZAPPLY_QUEUE_RESPONSES": return editAnswers(async () => {
        const { pendingResponses } = await store.get("pendingResponses");
        // Merged on the same normalisation the server uses, so re-answering one
        // question replaces its queued entry instead of adding a near-duplicate
        // that differs only by an asterisk or stray punctuation.
        const merged = new Map((pendingResponses ?? []).map((r) => [queueKey(r.question), r]));
        for (const r of (msg.responses ?? [])) {
          if (!r?.question || !String(r.answer ?? "").trim()) continue;
          const key = queueKey(r.question);
          if (!key) continue;
          merged.set(key, { ...r, queuedAt: Date.now() });
        }
        await store.set({ pendingResponses: Array.from(merged.values()).slice(-500) });
        await refreshBadge();
        return respond({ ok: true, pending: merged.size });
      });

      case "ZAPPLY_GET_PENDING": {
        const { pendingResponses } = await store.get("pendingResponses");
        return respond({ ok: true, data: { responses: pendingResponses ?? [] } });
      }

      /**
       * Discard the local queue without uploading it.
       *
       * The queue fills up with whatever was typed into a form, which includes
       * typos and answers that only ever made sense for one posting. Until now
       * the only way out of it was to sync — pushing all of that into the
       * dashboard's Saved Answers, where it would be reused on the next
       * application. This drops the queue and touches nothing on the server:
       * answers already saved in the dashboard are unaffected.
       */
      /**
       * Drop one queued answer, leaving the rest of the queue alone.
       *
       * Clear was all-or-nothing, so a single bad answer meant discarding
       * everything else waiting with it. Matched on the same normalisation the
       * queue is keyed by, so the entry removed is the one shown.
       */
      case "ZAPPLY_DELETE_PENDING": return editAnswers(async () => {
        const { pendingResponses } = await store.get("pendingResponses");
        const queue = pendingResponses ?? [];
        const target = queueKey(msg.question);
        const kept = queue.filter((r) => queueKey(r.question) !== target);
        await store.set({ pendingResponses: kept });
        const { session } = await store.get("session");
        setBadge(
          kept.length ? String(Math.min(99, kept.length)) : (session?.profile ? "" : "!"),
          kept.length ? "#FFB020" : (session?.profile ? "#00C2A8" : "#FFB020")
        );
        return respond({ ok: true, data: { removed: queue.length - kept.length, pending: kept.length } });
      });

      case "ZAPPLY_CLEAR_PENDING": return editAnswers(async () => {
        const { pendingResponses, heldAnswers } = await store.get(["pendingResponses", "heldAnswers"]);
        /**
         * Clear means clear.
         *
         * This only removed `pendingResponses`. Held answers were added later
         * and live in their own key, so they survived every Clear and were
         * counted and listed again the moment the popup reopened — the same
         * answers coming back "again and again" however many times Clear was
         * confirmed.
         */
        const cleared = (pendingResponses?.length ?? 0) + (heldAnswers?.length ?? 0);
        /**
         * Clear empties the list. It does not mute the questions.
         *
         * Each cleared *answer* is remembered so the identical capture cannot
         * bounce straight back, but the question stays open: answer it again,
         * or differently, and the new answer is captured normally. The previous
         * version recorded the bare question with no expiry, so one Clear
         * stopped those questions ever being captured again — and since the
         * list filled itself with untouched fields, Clear was the obvious thing
         * to press. That combination is what made saving answers look
         * permanently broken.
         */
        const { dismissedAnswers } = await store.get("dismissedAnswers");
        const dismissed = pruneDismissals(dismissedAnswers);
        const now = Date.now();
        (heldAnswers ?? []).forEach((r) => {
          const k = dismissalKey(r.question, r.answer);
          if (k) dismissed[k] = now;
        });
        const trimmed = Object.fromEntries(
          Object.entries(dismissed).sort((a, b) => b[1] - a[1]).slice(0, 500)
        );
        await store.remove(["pendingResponses", "heldAnswers"]);
        await store.set({ dismissedAnswers: trimmed });
        await refreshBadge();
        return respond({ ok: true, data: { cleared } });
      });

      /**
       * Sync now is two-way, and the pull half is the half that matters most:
       * answers the user typed into the dashboard's Saved Answers tab only
       * reach the extension through a bootstrap fetch. The old version returned
       * early whenever the local queue happened to be empty, so a user who had
       * only *added* answers in the dashboard pressed Sync now and pulled
       * nothing. The refresh now always runs.
       */
      case "ZAPPLY_SYNC_PENDING": {
        return respond(await syncPending());
      }

      /* --- application tracking sync (never receives saved-response auto flushes) --- */
      case "ZAPPLY_SYNC": {
        const payload = { ...(msg.payload ?? {}), responses: [] };
        const res = await api("/api/extension/sync", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        if (res.ok && msg.payload?.application) {
          const { stats } = await store.get("stats");
          const next = { ...(stats ?? { applications: 0 }) };
          next.applications = (next.applications ?? 0) + 1;
          await store.set({ stats: next });
        }
        return respond(res);
      }

      /* --- premium: profile scoring --- */
      case "ZAPPLY_SCORE": {
        return respond(await api("/api/ai/score", { method: "POST", body: JSON.stringify(msg.payload) }));
      }

      /* --- premium: generated answer --- */
      case "ZAPPLY_ANSWER": {
        return respond(await api("/api/ai/answer", { method: "POST", body: JSON.stringify(msg.payload) }));
      }

      /* --- duplicate detection --- */
      case "ZAPPLY_CHECK": {
        return respond(await api("/api/extension/check", { method: "POST", body: JSON.stringify(msg.payload) }));
      }

      /* --- the packaged default, so the popup doesn't hardcode localhost --- */
      case "ZAPPLY_GET_API_BASE": {
        return respond({ ok: true, data: { apiBase: await apiBase(), packagedDefault: DEFAULT_API } });
      }

      case "ZAPPLY_OPEN_DASHBOARD": {
        chrome.tabs.create({ url: `${await apiBase()}/dashboard` });
        return respond({ ok: true });
      }

      default:
        return respond({ ok: false, error: "Unknown message." });
    }
  })().catch((err) => respond({ ok: false, error: err?.message || "Zapply could not complete this action. Please retry." }));

  return true; // keep the channel open for the async work above
});

/* ------------------------------------------------------------------ */
/*  Lifecycle                                                          */
/* ------------------------------------------------------------------ */

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  const { apiBase: existing } = await store.get("apiBase");
  if (!existing) await store.set({ apiBase: DEFAULT_API });

  if (reason === "install") {
    chrome.tabs.create({ url: `${await apiBase()}/auth?mode=signup` });
    setBadge("1", "#FFB020");
  }
});

chrome.runtime.onStartup.addListener(() => refreshSession());

// Returning from the dashboard to a job page should pick up whatever changed —
// but at most once a minute, not on every tab switch.
chrome.tabs.onActivated.addListener(() => maybeRefreshSession());

/** Keyboard shortcut — fill the active tab on demand. */
chrome.commands?.onCommand.addListener(async (command) => {
  if (command !== "run-autofill") return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: "ZAPPLY_RUN" });
});
