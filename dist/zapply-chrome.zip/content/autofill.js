/**
 * ZAPPLY CONTENT SCRIPT
 * ---------------------
 * Runs on every page. Decides whether the page is a job application, fills it,
 * captures whatever the user answers by hand, and reports the result.
 *
 * Flow:
 *   detect ATS -> collect fields -> plan every value -> write once
 *   -> reconcile what genuinely failed -> watch for submit -> sync to the API
 *
 * One click is one pass. Earlier builds looped: a first fill, two rescans, an
 * AI pass, a retry pass and a validation pass, each of which called the setter
 * twice per field. On a Workday or SuccessFactors form that meant the same
 * dropdown was opened four or five times, which is what the user saw as
 * flickering — and while several menus were on screen at once, options from
 * one row's list were being scored against the next row's field. Now every
 * value is decided before anything is written, each control is written once,
 * and a dropdown is never opened while another one is still open.
 */

(() => {
  if (window.__zapplyLoaded) return;
  window.__zapplyLoaded = true;

  const M = window.ZAPPLY_MATCHER;
  const RULES = window.ZAPPLY_FIELD_MAP;
  const ATS = window.ZAPPLY_ATS;
  if (!M || !RULES || !ATS) return;

  const state = {
    session: null,      // { profile, settings, responses, premium }
    adapter: null,
    lastRun: null,
    unmatched: [],      // fields we couldn't answer — watched for manual input
    captured: new Map(),// question -> answer typed by the user
    filling: false,
    profile: null,      // the profile actually used (Premium may pick a different one)
    scoring: null,      // { score, reason, label } from Premium profile scoring
    drafted: new Set(), // elements filled by AI — the user must review these
    engaged: false,     // watchers attached: set once this looks like an application
    duplicate: null,    // a prior application for this posting, if any
    allFields: [],      // everything scanned on the last run
    stopRequested: false,
    manualSessionActive: false,
    completedRun: false,
    runId: 0,           // bumped per click; scopes "already written" to one pass
    // Programmatic writes can cause trusted change/click events after a widget
    // finishes rendering. Keep a short-lived provenance ledger outside the DOM
    // so a Workday/Ashby re-render cannot turn Zapply's own value into a
    // "manual" pending answer simply because the original node was replaced.
    programmaticAnswers: new Map(), // fingerprint -> { answer, expiresAt }
  };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  /* ================================================================== */
  /*  Messaging                                                          */
  /* ================================================================== */

  const send = (message) =>
    new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(message, (res) => {
          if (chrome.runtime.lastError) return resolve({ ok: false, error: chrome.runtime.lastError.message });
          resolve(res ?? { ok: false });
        });
      } catch {
        resolve({ ok: false });
      }
    });

  chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
    if (msg?.type?.startsWith("ZAPPLY_PENDING")) {
      if (handlePendingCommand(msg, respond)) return true;
    }
    if (msg?.type === "ZAPPLY_RUN") {
      if (window.top !== window) return respond({ ok: true, data: { child: true } });
      relayToChildFrames("ZAPPLY_RUN");
      run({ manual: true }).then((r) => respond(r));
      return true;
    }
    if (msg?.type === "ZAPPLY_STOP") {
      relayToChildFrames("ZAPPLY_STOP");
      state.stopRequested = true;
      state.manualSessionActive = false;
      return respond({ ok: true });
    }
    if (msg?.type === "ZAPPLY_STATUS") {
      respond({
        ok: true,
        isApplication: isApplicationPage(),
        ats: state.adapter?.label ?? null,
        lastRun: state.lastRun,
        duplicate: state.duplicate,
        profileLabel: state.profile?.label ?? null,
      });
      return true;
    }
    return false;
  });

  /* ================================================================== */
  /*  Page classification                                                */
  /* ================================================================== */

  function isApplicationPage() {
    const urlHit = /apply|application|careers?|job|candidate|opening|position|requisition/i.test(location.href);
    const inputs = document.querySelectorAll(
      'input[type="text"], input[type="email"], input[type="tel"], input:not([type]), textarea'
    );
    /**
     * A step made of choices is still an application step.
     *
     * This counted text boxes and nothing else, so a page of radio groups,
     * checkboxes and dropdowns — a demographics step, an eligibility
     * questionnaire, the second page of almost any Workday application —
     * scored zero here, the content script disengaged, and nothing the
     * applicant answered on it was ever recorded.
     */
    const choices = document.querySelectorAll(
      'select, input[type="radio"], input[type="checkbox"], [role="radiogroup"], [role="combobox"], [role="listbox"]'
    );
    const formHit = inputs.length + choices.length >= 3;
    const fileHit = Boolean(document.querySelector('input[type="file"]'));
    const eeoHit = /gender|veteran|disability|ethnicity|race/i.test(document.body?.innerText?.slice(0, 30000) || "");
    return [urlHit, formHit, fileHit, eeoHit].filter(Boolean).length >= 2;
  }

  function isExcluded(settings) {
    const list = settings?.excludedDomains ?? [];
    return list.some((d) => d && location.hostname.includes(d.trim()));
  }

  /* ================================================================== */
  /*  Field collection                                                   */
  /* ================================================================== */

  function collectSearchRoots() {
    const roots = [document];
    const seen = new Set(roots);
    const visit = (root) => {
      try {
        root.querySelectorAll("*").forEach((el) => {
          if (el.shadowRoot && !seen.has(el.shadowRoot)) {
            seen.add(el.shadowRoot);
            roots.push(el.shadowRoot);
            visit(el.shadowRoot);
          }
        });
      } catch {}
    };
    visit(document);
    return roots;
  }

  /**
   * Is this hidden control sitting inside a field the applicant can see?
   *
   * A select that a widget has replaced is invisible itself but lives in a
   * visible field wrapper. A select inside a collapsed step or an inactive tab
   * has nothing visible above it either — and filling that would put answers
   * into a part of the form nobody is looking at.
   */
  function hasVisibleHost(el) {
    let node = el.parentElement;
    for (let d = 0; node && d < 6; d++, node = node.parentElement) {
      if (node === document.body || node === document.documentElement) break;
      const style = getComputedStyle(node);
      // An ancestor that is switched off takes the whole region with it. The
      // visible page further up does not make this control reachable.
      if (style.display === "none" || style.visibility === "hidden") return false;
      const rect = node.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) return true;
    }
    return false;
  }

  /** Rule keys that belong to a repeated Work Experience / Education block. */
  const EXPERIENCE_KEYS = new Set([
    "currentCompany", "currentTitle", "employmentType", "experienceLocation",
    "experienceLocationType", "responsibilities", "experienceStartDate",
    "experienceEndDate", "experienceStartMonth", "experienceStartYear",
    "experienceEndMonth", "experienceEndYear", "experienceDatePart", "currentJob",
  ]);
  const EDUCATION_KEYS = new Set([
    "school", "degree", "fieldOfStudy", "educationLocation", "gpa",
    "graduationDate", "educationStartMonth", "educationStartYear",
    "educationEndMonth", "educationEndYear", "educationDatePart",
  ]);

  /**
   * Keys that appear more than once inside a *single* row, so they can never
   * mark where one row ends and the next begins.
   *
   * One job has two dates, and on Workday each of those is two more boxes —
   * `MM` and `YYYY`. The row finder picks the repeated key with the most
   * occurrences when no Company or Title is available, so on a form with one
   * job it chose the date parts, read the four date boxes as four separate
   * jobs, and asked the profile for jobs 2, 3 and 4. There are none, so `To`
   * was planned as blank and left blank — a required field the applicant then
   * had to fill in by hand on every Workday application.
   */
  const MULTI_PER_ROW_KEYS = new Set([
    "experienceStartDate", "experienceEndDate", "experienceDatePart",
    "experienceStartMonth", "experienceStartYear", "experienceEndMonth", "experienceEndYear",
    "graduationDate", "educationDatePart",
    "educationStartMonth", "educationStartYear", "educationEndMonth", "educationEndYear",
  ]);

  /**
   * Works out which repeated block each field belongs to.
   *
   * A numbered section heading is authoritative when the page provides one
   * ("Work Experience 2", "Professional Experience (1)"). Greenhouse and Oracle
   * provide nothing, so the rows are instead derived from the anchor field —
   * the Company or School box, which appears exactly once per entry — and every
   * other field is indexed by which anchor's container encloses it.
   *
   * Counting each rule key's occurrences, as the previous build did, silently
   * mis-numbered any form where the fields were not in a tidy repeating order,
   * which is why the wrong employer and the wrong dates were showing up.
   */
  function assignRowIndexes(fields, keys, anchorPreference) {
    const family = fields.filter((f) => keys.has(f.rule?.key));
    if (!family.length) return;

    // Repeated DOM rows are more reliable than a section heading. A page often
    // has one outer "Work Experience" heading plus several cloned rows, so
    // treating that outer heading as authoritative can give every row index 0.
    // Once that happens the profile's first role is copied into every row.
    const counts = new Map();
    family.forEach((f) => counts.set(f.rule.key, (counts.get(f.rule.key) || 0) + 1));
    const anchorKey =
      anchorPreference.find((k) => (counts.get(k) || 0) > 1) ||
      [...counts.entries()].sort((a, b) => b[1] - a[1])
        .find(([key, n]) => n > 1 && !MULTI_PER_ROW_KEYS.has(key))?.[0];

    let anchored = false;
    if (anchorKey) {
      const anchors = family.filter((f) => f.rule.key === anchorKey).map((f) => f.el);
      const rows = M.rowsFromAnchors(anchors);
      if (rows.length >= 2) {
        anchored = true;
        const numbering = rowNumbering(rows, family);
        family.forEach((field) => {
          const i = rows.findIndex((row) => row.contains(field.el));
          if (i >= 0) field.index = numbering[i];
        });
      }
    }

    // Headings are the fallback for fields that are outside the repeated row
    // container (for example an isolated "Currently employed" control).
    // Never overwrite an index already established by the real row.
    for (const field of family) {
      if (Number.isInteger(field.index)) continue;
      const fromHeading = M.sectionContext?.(field.el)?.index;
      if (Number.isInteger(fromHeading)) field.index = fromHeading;
    }

    const unresolved = family.filter((f) => !Number.isInteger(f.index));
    if (!unresolved.length) { reconcileRows(family); return; }

    if (!anchored) {
      unresolved.forEach((f) => { if (!Number.isInteger(f.index)) f.index = 0; });
      reconcileRows(family);
      return;
    }

    // If a field is in an anchored family but could not be placed, use the
    // nearest row's index instead of falling back to role 0. This keeps a
    // missing widget from stealing the first job's value.
    const rows = M.rowsFromAnchors(
      family.filter((f) => f.rule.key === anchorKey).map((f) => f.el)
    );
    unresolved.forEach((field) => {
      const i = rows.findIndex((row) => row.contains(field.el));
      if (i >= 0) field.index = i;
    });

    // Truly isolated fields have no row context; only then is index 0 safe.
    unresolved.forEach((f) => { if (!Number.isInteger(f.index)) f.index = 0; });
    reconcileRows(family);
  }

  /**
   * Which entry of the profile each row stands for.
   *
   * Normally that is simply the row's position on the page. But a page can
   * carry two separate repeated families — "Work Experience 1/2" followed by
   * "Professional Experience (1)/(2)" — and counting straight through them made
   * the first row of the second family the *third* job. The profile has two, so
   * the lookup returned nothing and every box in that section, dates included,
   * was left blank.
   *
   * Rows are grouped by the wording of the heading above them, ignoring its
   * number, and counted within that group. A page with one heading and several
   * cloned rows underneath has a single group, so it is unaffected.
   */
  function rowNumbering(rows, family) {
    const positional = rows.map((_, i) => i);

    const stemOf = (row) => {
      const inside = family.find((f) => row.contains(f.el));
      if (!inside) return "";
      let title = "";
      try { title = M.sectionContext?.(inside.el)?.title || ""; } catch { return ""; }
      // "Professional Experience (2)" and "Professional Experience (1)" are the
      // same section; the number is what tells the rows apart, not the family.
      return title.toLowerCase().replace(/[^a-z]+/g, " ").trim();
    };

    const stems = rows.map(stemOf);
    if (stems.some((s) => !s)) return positional;
    if (new Set(stems).size < 2) return positional;

    const seen = new Map();
    return stems.map((stem) => {
      const n = seen.get(stem) ?? 0;
      seen.set(stem, n + 1);
      return n;
    });
  }

  /**
   * Every field in one row must carry the same index.
   *
   * Indexes are worked out per field, from whichever numbered heading each one
   * happens to resolve to. Two boxes sitting in the same row can resolve
   * differently — a heading nested one level deeper, a wrapper that breaks the
   * ancestor walk — and then one field reads row 2 of the profile while the box
   * beside it reads row 3. Where row 3 does not exist the lookup returns nothing
   * and that single box is left blank, which is the Job Title empty beside a
   * Company that filled from the same entry.
   *
   * The fields are grouped by the container they actually share and the row is
   * given one index: the one most of its fields agree on, falling back to the
   * row's position on the page. Disagreement inside a row is always a
   * resolution error, never a real difference — a row describes one job.
   */
  function reconcileRows(family) {
    const groups = new Map();
    for (const field of family) {
      const row = rowContainerOf(field.el, family);
      if (!row) continue;
      if (!groups.has(row)) groups.set(row, []);
      groups.get(row).push(field);
    }
    if (groups.size < 2) return;

    // Page order decides the fallback numbering.
    const ordered = [...groups.entries()].sort((a, b) => {
      const pos = a[0].compareDocumentPosition(b[0]);
      return pos & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : pos & Node.DOCUMENT_POSITION_PRECEDING ? 1 : 0;
    });

    ordered.forEach(([, members], ordinal) => {
      const votes = new Map();
      members.forEach((f) => {
        if (!Number.isInteger(f.index)) return;
        votes.set(f.index, (votes.get(f.index) || 0) + 1);
      });
      let agreed = ordinal;
      let best = 0;
      for (const [value, count] of votes) {
        if (count > best) { best = count; agreed = value; }
      }
      members.forEach((f) => { f.index = agreed; });
    });
  }

  /** The smallest ancestor that holds this field and no other row's fields. */
  function rowContainerOf(el, family) {
    let node = el.parentElement;
    for (let depth = 0; node && depth < 8; depth++, node = node.parentElement) {
      const inside = family.filter((f) => node.contains(f.el));
      // A row holds several of the row's own fields but not all of them.
      if (inside.length >= 2 && inside.length < family.length) return node;
    }
    return null;
  }

  /** Controls a person could actually answer — used to size up a candidate root. */
  const ANSWERABLE_PROBE =
    'input:not([type="hidden"]):not([type="submit"]):not([type="reset"]):not([type="button"]), ' +
    'textarea, select, [role="combobox"], [role="radio"], [role="checkbox"], [contenteditable="true"]';

  /**
   * Regions that are never the application itself: the site's own search box,
   * a newsletter signup, a cookie banner, a login widget. These are excluded
   * from the scan so widening it never means answering the page's furniture.
   */
  const PAGE_CHROME_RE =
    /(^|[\s\-_])(site-?search|searchform|search-?form|newsletter|subscribe|cookie|consent|gdpr|login|log-?in|sign-?in|signin|locale|language|currency|promo-?code|coupon|chat|livechat|support-?widget)([\s\-_]|$)/i;

  /** A button that changes the form rather than answering a question. */
  const ACTION_BUTTON_RE =
    /^(add|remove|delete|save|next|back|previous|continue|submit|upload|browse|attach|edit|cancel|close|clear|reset|sign\s*in|log\s*in|apply|search|skip|done|finish)\b/i;

  function isActionButton(el) {
    try {
      const name = (M.visibleText?.(el) || el.getAttribute("aria-label") || el.getAttribute("title") || "").trim();
      return name ? ACTION_BUTTON_RE.test(name) : false;
    } catch {
      return false;
    }
  }

  function looksLikePageChrome(root) {
    if (!root || root === document || root.nodeType === 11) return false;
    if (root.getAttribute?.("role") === "search") return true;
    const hint = [
      root.getAttribute?.("id"), root.getAttribute?.("name"), root.getAttribute?.("class"),
      root.getAttribute?.("aria-label"), root.getAttribute?.("action"), root.getAttribute?.("data-testid"),
    ].filter(Boolean).join(" ");
    return hint ? PAGE_CHROME_RE.test(hint) : false;
  }

  /** Is this individual control part of the page furniture rather than the form? */
  function inPageChrome(el) {
    try {
      if (el.closest?.('[role="search"]')) return true;
      const form = el.closest?.("form");
      if (form && looksLikePageChrome(form)) return true;
      const self = [
        el.getAttribute?.("name"), el.id, el.getAttribute?.("aria-label"),
        el.getAttribute?.("placeholder"),
      ].filter(Boolean).join(" ");
      return self ? PAGE_CHROME_RE.test(self) : false;
    } catch {
      return false;
    }
  }

  function countAnswerable(root) {
    let n = 0;
    try {
      root.querySelectorAll(ANSWERABLE_PROBE).forEach((el) => {
        if (el.disabled || el.type === "hidden") return;
        if (inPageChrome(el)) return;
        if (M.isFillable(el) || (el.tagName === "SELECT" && hasVisibleHost(el))) n++;
      });
    } catch {}
    return n;
  }

  /**
   * Where to look for the application.
   *
   * The adapter's `formSelector` used to win outright: whatever it matched
   * became the entire search area, and the whole document was consulted only
   * when it matched nothing at all. On a portal that renders its application
   * outside any <form> — most React and Vue career sites — the one <form> on
   * the page is usually the header search box, so the scan found a single
   * search input and the profile went completely unused. That is the "profile
   * data isn't used on some applications" report.
   *
   * The matched forms are now checked against the rest of the page before they
   * are trusted: they are used as the scope only when they actually hold the
   * bulk of what a person has to answer. Otherwise the scan widens to the full
   * document, minus the site's own widgets.
   */
  function chooseScanRoots(adapter, searchRoots) {
    const matched = [];
    for (const root of searchRoots) {
      try {
        root.querySelectorAll(adapter.formSelector || "form").forEach((form) => {
          if (!looksLikePageChrome(form)) matched.push(form);
        });
      } catch {}
    }
    if (!matched.length) return searchRoots;

    const inside = matched.reduce((n, root) => n + countAnswerable(root), 0);
    const onPage = searchRoots.reduce((n, root) => n + countAnswerable(root), 0);

    // The matched forms hold most of the answerable controls, so they are the
    // application. Scoping to them keeps unrelated widgets out of the results.
    if (inside >= 3 && inside >= onPage * 0.6) return matched;

    // Most of the form lives outside what matched. Widen rather than fill
    // nothing — a few extra highlighted fields beat an untouched application.
    return searchRoots;
  }

  /**
   * Put back anything the page threw away after the fill.
   *
   * Portals that hydrate after first paint re-render their sections from their
   * own model, which is still empty, and every value written before that
   * finished is wiped. The fill has already reported success by then and never
   * looks again, so the applicant reaches Next and is told the fields are
   * required — first and last name most often, because they are at the top and
   * therefore filled earliest.
   *
   * Two short passes are enough for the frameworks in play. A field is only
   * restored while it is genuinely empty, never after the applicant has touched
   * it, and never more than twice — so this cannot turn into the fill
   * repeatedly rewriting the form.
   */
  const SETTLE_DELAYS = [900, 2200];
  const MAX_SETTLE_FIXES = 2;

  /**
   * Repair a value the page is rejecting, whenever it starts rejecting it.
   *
   * The settle passes above run 900ms and 2200ms after a fill. Workday does not
   * validate then — it validates when Save & Continue is pressed, which may be
   * several minutes later, and only then renders "The field First Name is
   * required and must have a value" under a box plainly containing "Pradeep".
   * By that point nothing was watching, so the value was never committed and
   * the applicant had to retype it by hand.
   *
   * This watches for error markup appearing at any time and re-commits only the
   * fields Zapply wrote, only while they still hold what Zapply wrote, and at
   * most three times each. It cannot touch a field the applicant has edited and
   * it never fills anything that was not already filled, so it stays a repair
   * and never becomes a second autofill.
   */
  const MAX_REPAIRS = 3;
  let repairTimer = null;

  function repairFlaggedFields() {
    if (state.filling || state.stopRequested) return;
    for (const [el, record] of Array.from(state.applied ?? new Map())) {
      try {
        if (!document.contains(el)) { state.applied.delete(el); continue; }
        if (el.__zapplyUserEdited) continue;
        if ((el.__zapplyRepairs ?? 0) >= MAX_REPAIRS) continue;
        if (!M.flaggedInvalid?.(el)) continue;
        // Only if the box still holds what we put there. Anything else is the
        // applicant's, or the page's, and is not ours to overwrite.
        if (!M.hasValue(el) || !matchesWritten(el, String(readValue(record.field) ?? ""))) continue;

        el.__zapplyRepairs = (el.__zapplyRepairs ?? 0) + 1;
        M.retypeValue(el, record.value);
      } catch {}
    }
  }

  function watchValidation() {
    const ping = () => {
      clearTimeout(repairTimer);
      repairTimer = setTimeout(repairFlaggedFields, 400);
    };
    try {
      new MutationObserver((records) => {
        for (const r of records) {
          // Only wake up for something that looks like a validation message.
          const touched = [...(r.addedNodes ?? [])];
          if (r.type === "attributes" && r.attributeName === "aria-invalid") return ping();
          for (const node of touched) {
            const text = node.textContent || "";
            if (/\b(is required|must have a value|invalid|cannot be blank)\b/i.test(text)) return ping();
          }
        }
      }).observe(document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["aria-invalid"],
      });
    } catch {}
  }

  function scheduleSettleCheck() {
    if (state.settleScheduled) return;
    state.settleScheduled = true;
    SETTLE_DELAYS.forEach((delay) => setTimeout(() => { settlePass(); }, delay));
  }

  async function settlePass() {
    if (state.filling || state.stopRequested) return;
    const entries = Array.from(state.applied ?? new Map());
    if (!entries.length) return;

    let restored = 0;
    for (const [el, record] of entries) {
      if (state.stopRequested) break;
      if (!document.contains(el)) { state.applied.delete(el); continue; }
      if (el.__zapplyUserEdited) continue;
      if (!record.readable) continue;
      if (el.__zapplyNoMatch) continue;
      if ((el.__zapplySettleFixes ?? 0) >= MAX_SETTLE_FIXES) continue;

      let holds = true;
      try { holds = M.hasValue(el); } catch {}

      // The value is still in the box, but the page has flagged the field as
      // required or invalid anyway — it took the text and never registered it.
      // That is the "Address Line 1 is required" seen with the address plainly
      // in the box. Writing it again through a clear-then-set transition is
      // what gets it into the page's own model.
      if (holds) {
        if (!M.flaggedInvalid?.(el)) continue;
        el.__zapplySettleFixes = (el.__zapplySettleFixes ?? 0) + 1;
        try { if (M.retypeValue(el, record.value)) restored++; } catch {}
        continue;
      }

      el.__zapplySettleFixes = (el.__zapplySettleFixes ?? 0) + 1;
      // The element was cleared by a re-render, so the guards that stop a field
      // being written twice in one pass have to be released for this one write.
      el.__zapplyWrittenRun = null;
      try {
        state.filling = true;
        if (await applyValue(record.field, record.value, record.rule)) restored++;
      } catch {
      } finally {
        state.filling = false;
      }
    }

    if (restored) {
      state.lastRun = { ...(state.lastRun ?? {}), restored: (state.lastRun?.restored ?? 0) + restored };
      if ((state.session?.settings ?? {}).showOverlay !== false) {
        try {
          overlay.show({
            tone: "partial",
            title: `Restored ${restored} field${restored === 1 ? "" : "s"}`,
            body: "The page cleared them while it finished loading. Check them before submitting.",
          });
        } catch {}
      }
    }
  }

  /**
   * Workday account settings. Passwords are intentionally read from the
   * dashboard Saved Answers list only; the extension has no separate password
   * input or browser-local password fallback.
   */
  async function getAccountSettings() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(["zapplyAutoSubmitAccount"], (r) => resolve(r || {}));
      } catch {
        resolve({});
      }
    });
  }

  /** Every visible, fillable password box on the page — one for sign-in, two for create-account. */
  function passwordFields() {
    return Array.from(document.querySelectorAll('input[type="password"]')).filter((el) => M.isFillable(el));
  }

  /**
   * Looks the page's own password field(s) up in the saved-answers list —
   * exactly the mechanism every other field uses (findSavedAnswer below), so
   * a response saved under a question like "Password" is reused here the same
   * way a saved "Phone number" is reused on any other form. Only a field the
   * page itself is asking is checked, in whichever order they appear, so a
   * "Confirm password" box has the same chance to match as "Password" does.
   */
  function resolveSavedPassword() {
    for (const el of passwordFields()) {
      const field = { el, label: M.deriveLabel(el), kind: "text" };
      const hit = findSavedAnswer(field);
      if (hit?.answer) return hit.answer;
    }
    return null;
  }

  function fillAccountPasswordFields(password) {
    let filled = 0;
    for (const el of passwordFields()) {
      if (el.__zapplyUserEdited || M.hasValue(el)) continue;
      try {
        if (M.setTextValue(el, password)) filled++;
      } catch {}
    }
    return filled;
  }

  /**
   * The button that actually submits the sign-in or create-account form.
   * Workday tags these with data-automation-id; everything else falls back to
   * matching the button's own text, scoped to the form the password lives in
   * so a "Forgot password?" or "Back" link is never mistaken for it.
   */
  function findAccountSubmitButton() {
    const scope = passwordFields()[0]?.closest("form, [role='main'], [data-automation-id='shellRootRouterOutlet'], body") || document;
    const candidates = Array.from(
      scope.querySelectorAll(
        "button[data-automation-id='createAccountSubmitButton'], button[data-automation-id='signInSubmitButton'], " +
        "button[data-automation-id*='submit'], button[type='submit'], input[type='submit'], [role='button']"
      )
    );
    return candidates.find((el) => {
      if (!M.isFillable(el) || el.disabled || el.getAttribute("aria-disabled") === "true") return false;
      const t = (el.textContent || el.value || el.getAttribute("aria-label") || "").trim().toLowerCase();
      return /create account|sign in|log in|continue|submit|next/.test(t);
    }) || null;
  }

  /**
   * Workday can render the password immediately while its React state is still
   * one tick behind. Clicking the submit button at that exact moment makes the
   * UI look filled but the server receives an empty credential. Wait briefly
   * for every visible password control to contain the saved value and for the
   * submit control to become enabled. This is a bounded readiness check, not a
   * second autofill pass.
   */
  async function submitAccountWhenReady() {
    const deadline = Date.now() + 2500;
    while (Date.now() < deadline && !state.stopRequested) {
      const fields = passwordFields();
      const readyPasswords = fields.length > 0 && fields.every((el) => String(el.value ?? "").trim().length > 0);
      const btn = findAccountSubmitButton();
      if (readyPasswords && btn && !btn.disabled && btn.getAttribute("aria-disabled") !== "true") {
        // Let controlled-field onChange/state updates flush before the click.
        await sleep(80);
        const latest = findAccountSubmitButton();
        if (latest && !latest.disabled && latest.getAttribute("aria-disabled") !== "true") {
          latest.click();
          return true;
        }
      }
      await sleep(100);
    }
    return false;
  }

  /**
   * Is this the sign-in or create-account step rather than the application?
   *
   * Workday's apply flow opens on one of these, and filling it half way — an
   * email address and nothing else, because a password is not something to
   * invent — looks like the fill worked when nothing has happened. The account
   * step belongs to the applicant; the fill starts once they are through it.
   */
  function authPageReason() {
    if (!document.querySelector('input[type="password"]')) return null;

    const hay = [
      location.pathname, location.search, document.title,
      M.visibleText?.(document.querySelector("h1, h2")) || "",
      Array.from(document.querySelectorAll("[data-automation-id]"))
        .slice(0, 40).map((n) => n.getAttribute("data-automation-id")).join(" "),
    ].join(" ").toLowerCase();

    if (/create\s*account|createaccount|register|sign\s*up|signup/.test(hay)) return "createAccount";
    if (/sign\s*in|signin|log\s*in|login|forgot|reset\s*password/.test(hay)) return "signIn";

    // A password box on a page with no resume upload is an account form
    // whatever it calls itself. With one, it's an application that happens to
    // ask the applicant to choose a password, and that is left to them too.
    return document.querySelector('input[type="file"]') ? null : "signIn";
  }

  function collectFields(adapter) {
    const searchRoots = collectSearchRoots();
    const roots = chooseScanRoots(adapter, searchRoots);

    const seen = new Set();
    const fields = [];

    roots.forEach((root) => {
      try {
        root
          .querySelectorAll(
            'input, textarea, select, ' +
            '[role="combobox"], [role="textbox"][contenteditable="true"], ' +
            '[aria-haspopup="listbox"], [aria-haspopup="menu"], ' +
            'button[data-automation-id*="Dropdown"], button[data-automation-id*="Prompt"], ' +
            // Plain buttons are scanned so segmented Yes/No controls are found.
            // Everything that is not a choice group or a menu trigger is
            // rejected a few lines below, so this widens detection only.
            'button, [role="button"], ' +
            'div[role="button"][aria-expanded], ' +
            '[role="checkbox"], [role="radio"], ' +
            '[data-qa], [data-testid], [data-test-id], [contenteditable="true"]'
          )
          .forEach((el) => {
            if (seen.has(el)) return;
            seen.add(el);
            // The scan may cover the whole page, so the site's own furniture is
            // filtered out here rather than being answered or flagged.
            if (inPageChrome(el)) return;
            // A dropdown that a library has replaced with its own markup keeps
            // its real <select> in the page but hides it. That select is the
            // value the form submits, so it is collected even though it cannot
            // be seen — otherwise a widget with no ARIA of its own (iCIMS's
            // "— Make a Selection —" country picker) is never even attempted.
            const hiddenButBacking =
              el.tagName === "SELECT" && !el.disabled && (el.options?.length ?? 0) > 1 &&
              hasVisibleHost(el);
            if (!M.isFillable(el) && !hiddenButBacking) return;
            if (["submit", "reset", "image"].includes(el.type)) return;
            // Never treat an option inside an open menu as a form field.
            if (el.closest?.('[role="listbox"], [role="menu"], [role="option"]')) return;

            // A segmented choice control — two or more plain buttons acting as
            // one question. Collected as a single radio-style field, so the
            // group is answered once and reported once.
            const segments = M.choiceButtonGroup?.(el);
            if (segments?.length) {
              const container = segments[0].parentElement;
              if (container && !container.dataset.zapplyChoiceKey) {
                container.dataset.zapplyChoiceKey = `c${Math.random().toString(36).slice(2)}`;
              }
              const groupKey = `choice|${container?.dataset?.zapplyChoiceKey || `single-${fields.length}`}`;
              if (fields.some((f) => f._groupKey === groupKey)) return;
              // Always anchor on the first segment so the derived label and the
              // row index don't depend on which button the scan reached first.
              const anchor = segments[0];
              seen.add(anchor);
              const segLabel = M.deriveLabel(anchor);
              fields.push({
                el: anchor,
                label: segLabel,
                kind: "radio",
                rule: M.matchRule(anchor, segLabel, RULES),
                _groupKey: groupKey,
              });
              return;
            }

            if (el.tagName === "BUTTON" || el.getAttribute("role") === "button") {
              const popup = el.getAttribute("aria-haspopup");
              const opensMenu =
                el.getAttribute("role") === "combobox" ||
                popup === "listbox" || popup === "menu" || popup === "true" ||
                /dropdown|select|prompt/i.test(el.getAttribute("data-automation-id") || "") ||
                // Workday renders most of its selects as a <button> carrying
                // nothing but `aria-expanded` — no aria-haspopup, no telling
                // automation id — so this has to stay. Excluding it made every
                // one of those dropdowns invisible to the fill, which is what
                // stopped Workday working.
                el.getAttribute("aria-expanded") !== null;
              if (!opensMenu) return;
              // The name is what separates a dropdown from a control that
              // changes the form: clicking "Add" or "Delete" is what opened
              // education section after education section. That check, not the
              // aria-expanded one above, is the guard that matters.
              if (isActionButton(el)) return;
            } else if (el.type === "button") return;

            if (el.type === "radio" || el.type === "checkbox" ||
                el.getAttribute("role") === "radio" || el.getAttribute("role") === "checkbox") {
              const role = el.getAttribute("role") || el.type;
              const name = el.getAttribute("name");
              const container = el.closest("fieldset, [role='radiogroup'], [role='group']");
              if (container && !container.dataset.zapplyGroupKey) {
                container.dataset.zapplyGroupKey = `g${Math.random().toString(36).slice(2)}`;
              }
              const groupKey = `${role}|${name || container?.dataset?.zapplyGroupKey || `single-${fields.length}`}`;
              if (fields.some((f) => f._groupKey === groupKey && f.el !== el)) return;
              el.dataset.zapplyGroup = el.dataset.zapplyGroup || (name || container?.dataset?.zapplyGroupKey || `g${fields.length}`);
              const label = M.deriveLabel(el);
              fields.push({ el, label, kind: M.fieldKind(el), rule: M.matchRule(el, label, RULES), _groupKey: groupKey });
              return;
            }

            const label = M.deriveLabel(el);
            fields.push({ el, label, kind: M.fieldKind(el), rule: M.matchRule(el, label, RULES) });
          });
      } catch {}
    });

    // A decorated dropdown can be picked up twice — once as the visible widget
    // and once as the hidden select behind it. They are one question, so keep
    // whichever carries the better label and drop the other.
    const byControl = new Map();
    const deduped = [];
    for (const field of fields) {
      const key = M.backingSelect?.(field.el) ?? field.el;
      const existing = byControl.get(key);
      if (!existing) {
        byControl.set(key, field);
        deduped.push(field);
        continue;
      }
      if ((field.rule && !existing.rule) || (field.label?.length ?? 0) > (existing.label?.length ?? 0)) {
        deduped[deduped.indexOf(existing)] = field;
        byControl.set(key, field);
      }
    }

    assignRowIndexes(deduped, EXPERIENCE_KEYS, ["currentCompany", "currentTitle", "responsibilities"]);
    assignRowIndexes(deduped, EDUCATION_KEYS, ["school", "degree", "fieldOfStudy"]);
    deduped.forEach((f) => { if (!Number.isInteger(f.index)) f.index = 0; });
    return deduped;
  }

  /**
   * A choice field that has nothing to offer yet.
   *
   * "State/Province" reads "Please select a country" until Country is answered,
   * and iCIMS's "Please specify" stays empty until "How did you hear about us?"
   * is. Attempting these in page order fills neither, so they are set aside and
   * retried once everything else has been answered.
   */
  function isAwaitingParent(field) {
    const el = field.el;
    if (el.disabled || el.getAttribute?.("aria-disabled") === "true") return true;
    if (field.kind !== "select") return false;
    return !M.hasRealOptions(el);
  }

  /**
   * Workday often starts with one blank Work Experience row. If the saved
   * profile contains more roles, create the missing rows before filling so the
   * nth role from the profile lands in the nth ATS row.
   */
  async function ensureProfileRows(profile, adapter, kinds = ["experience", "education"]) {
    const experienceCount = kinds.includes("experience") && Array.isArray(profile?.experience) ? profile.experience.length : 0;
    const educationCount = kinds.includes("education") && Array.isArray(profile?.education) ? profile.education.length : 0;
    if (experienceCount <= 1 && educationCount <= 1) return;

    const sectionRe = (kind) => kind === "experience"
      ? /work\s+experience|employment|work\s+history|job\s+history|professional\s+experience/i
      : /education|school|university|college/i;

    const countRows = (kind) => {
      const keys = kind === "experience" ? EXPERIENCE_KEYS : EDUCATION_KEYS;
      const preference = kind === "experience"
        ? ["currentCompany", "currentTitle", "responsibilities"]
        : ["school", "degree", "fieldOfStudy"];
      const fields = collectFields(adapter).filter((f) => keys.has(f.rule?.key));
      if (!fields.length) return 0;

      // Count actual repeated anchors first. This is intentionally independent
      // of `field.index`: the old implementation used the indexer to decide
      // whether another row existed, while the indexer itself could collapse
      // two pre-rendered rows to index 0. That feedback loop clicked "Add" and
      // created a duplicate row containing the same profile data.
      const counts = new Map();
      fields.forEach((f) => counts.set(f.rule.key, (counts.get(f.rule.key) || 0) + 1));
      const anchorKey = preference.find((k) => (counts.get(k) || 0) >= 1) ||
        [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0];
      if (anchorKey) {
        const anchors = fields.filter((f) => f.rule.key === anchorKey).map((f) => f.el);
        if (anchors.length >= 2) {
          const rows = M.rowsFromAnchors(anchors);
          if (rows.length >= 2) return rows.length;
          // Two anchors are two rows even if an unusual wrapper makes the row
          // detector conservative. Never add another row merely because the
          // container could not be identified.
          return anchors.length;
        }
      }

      const indices = fields.map((f) => f.index).filter(Number.isInteger);
      return indices.length ? Math.max(...indices) + 1 : 1;
    };

    /**
     * How many rows this pass may create.
     *
     * The old ceiling was eight, and the only stop condition was countRows()
     * reporting enough rows. When an ATS renders its new sections in markup the
     * row indexer can't read, countRows never moves, the guard never fires, and
     * every one of those eight clicks lands — which is the reported "more than
     * seven education tabs". A row that never gets filled is an empty block the
     * applicant has to delete by hand, so the ceiling is now low and progress is
     * verified after every click.
     */
    const MAX_ADDED_ROWS = { experience: 5, education: 3 };

    const answerableCount = () => {
      try { return document.querySelectorAll(ANSWERABLE_PROBE).length; } catch { return 0; }
    };

    const clickAdds = async (kind, targetCount) => {
      if (targetCount <= 1) return;
      const re = sectionRe(kind);
      const limit = Math.min(MAX_ADDED_ROWS[kind] ?? 3, targetCount - 1);
      let rowsSeen = countRows(kind);
      let controlsSeen = answerableCount();

      for (let attempt = 0; attempt < limit; attempt++) {
        if (state.stopRequested) return;
        if (countRows(kind) >= targetCount) return;

        const add = Array.from(document.querySelectorAll('button, [role="button"], a, [data-automation-id]'))
          .filter((el) => M.isFillable(el))
          .find((el) => {
            const text = M.visibleText(el) || el.getAttribute("aria-label") || el.getAttribute("data-automation-id") || "";
            if (!/^add(?:\s+|$)|add\s+(another|new|work|experience|education|school|job)/i.test(text.trim())) return false;
            const parentText = M.visibleText(el.parentElement?.parentElement) || "";
            return re.test(`${text} ${parentText}`);
          });

        if (!add) return;
        M.ensureVisible(add);
        add.click?.();
        await sleep(320);

        // Neither the row count nor the number of answerable controls moved, so
        // that click achieved nothing. Repeating it would only stack up empty
        // sections, so the pass stops here rather than spending its whole
        // allowance discovering the same thing.
        const rowsNow = countRows(kind);
        const controlsNow = answerableCount();
        // Adding an ATS row must be proven by the row detector itself. Some
        // Workday renders briefly increase the number of controls while the
        // original row is rehydrating; treating that as a new row caused the
        // Add button to be clicked twice and created duplicate Work Experience
        // sections. If the real row count did not increase, stop rather than
        // manufacture another section.
        if (rowsNow <= rowsSeen) return;
        rowsSeen = rowsNow;
        controlsSeen = controlsNow;
      }
    };

    await clickAdds("experience", experienceCount);
    await clickAdds("education", educationCount);
  }

  /* ================================================================== */
  /*  Saved answers                                                      */
  /* ================================================================== */

  /**
   * Looks a question up in the user's saved answers.
   *
   * The derived label is several descriptions joined by " | ", so each one is
   * tried separately — matching the whole joined string diluted the score badly
   * enough that saved answers routinely failed to apply.
   */
  function findSavedAnswer(field) {
    const responses = state.session?.responses ?? [];
    if (!responses.length) return null;

    const el = field?.el;
    const candidates = [];

    /**
     * The group's own option labels, which must never be looked up as
     * questions. A radio group offering "Prefer not to say" would otherwise
     * search Saved Answers for that phrase and could match an unrelated record
     * on it — the mirror image of the capture bug, and just as wrong.
     */
    let options = new Set();
    try { options = optionTextsForField(field); } catch {}

    const addCandidate = (value) => {
      const text = String(value ?? "").trim();
      if (!text) return;
      const parts = text.split(" | ").map((x) => x.trim()).filter(Boolean);
      for (const part of parts) {
        if (part.length < 4) continue;
        if (options.has(answerKey(part))) continue;
        if (ANSWER_LIKE_RE.test(part)) continue;
        // A uuid is unique to this one form. Looking one up can only ever miss,
        // and a near-miss against an unrelated record is worse than a miss.
        if (looksMachineGenerated(part)) continue;
        if (!candidates.includes(part)) candidates.push(part);
      }
    };

    // Choice controls are commonly labelled with the *selected option* rather
    // than the question. The answer is saved under the real question heading,
    // so the same resolution has to run here or a synced radio, checkbox or
    // dropdown answer can never be found again on the next application.
    if (field) {
      try { addCandidate(primaryQuestion(field)); } catch {}
      try { groupAccessibleNames(el).forEach(addCandidate); } catch {}
      try { addCandidate(questionHeadingNear(el, options)); } catch {}
      try { addCandidate(field.question); } catch {}
      addCandidate(field.label);
    }

    if (el) {
      ["aria-label", "data-qa", "data-testid", "name", "id"].forEach((attr) => {
        const v = el.getAttribute?.(attr);
        if (v && v.trim()) addCandidate(M.humanize(v.trim()) || v.trim());
      });

      const labelledBy = el.getAttribute?.("aria-labelledby");
      if (labelledBy) {
        for (const id of labelledBy.split(/\s+/)) {
          const node = document.getElementById(id);
          if (node) addCandidate(M.visibleText?.(node) || node.textContent);
        }
      }
    }

    let best = null;
    for (const question of candidates.slice(0, 8)) {
      if (question.length < 4) continue;
      const hit = M.findSavedAnswer(question, responses);
      if (hit && (!best || (hit.confidence ?? 0) > (best.confidence ?? 0))) best = hit;
    }
    if (!best) return null;

    // Saved answers that identify an application question exactly (including an
    // alias captured on another ATS) are always eligible to replay. This is
    // deliberately checked before profile-derived values in planField so an
    // explicit Saved Answer remains the user's chosen answer.
    //
    // Fuzzy matches stay available, but only at a stronger threshold than the
    // general matcher default. This prevents an unrelated saved response from
    // winning just because two short labels share a few words.
    if ((best.confidence ?? 0) < 0.82) return null;

    // An exact match means the applicant answered this very question before,
    // by its normalized text or one of its recorded aliases. That outranks a
    // value derived from the profile; a merely similar question does not.
    best.exact = (best.confidence ?? 0) >= 0.999;

    /**
     * A saved answer is not allowed to override an identity or voluntary
     * disclosure field.
     *
     * These are the fields with one correct answer that already lives in the
     * profile, and they are the ones the queue was poisoned with: a generated
     * "Yes" captured off a CC-305 Name box came back as a saved answer and was
     * replayed onto every later application, which is the loop the user
     * described — correcting it by hand only banked the correction against the
     * wrong question. The profile is authoritative here; the queue is not.
     */
    if (field?.rule?.blank) return null;
    if (field?.rule?.identity && !field.rule.eeo) return null;

    /**
     * Never into a contact or identity box, rule or no rule.
     *
     * The guard above only fires when a rule matched. When one did not — which
     * is exactly what happened to Workday's Phone Number box — the field was
     * open to any saved answer whose question looked similar, and it collected
     * the email address. These boxes have one source: the profile.
     */
    if (/\b(e-?mail|phone|mobile|telephone|country\s*code|area\s*code|extension|first\s*name|last\s*name|middle\s*name|full\s*name|date\s*of\s*birth|address\s*line|postal|zip\s*code)\b/i
        .test(String(field?.label ?? "").split("|")[0])) {
      return null;
    }

    /**
     * For a disclosure question the saved answer has to reduce to a real
     * branch of that same question. "Yes" saved against "Name" does not, and a
     * saved answer from a differently-worded portal that lands on another
     * branch must not be carried across either.
     */
    if (field?.rule?.eeo) {
      const savedId = M.eeoId(best.answer, field.label);
      if (!savedId) return null;
      const profileId = M.eeoId(field.rule.value?.(state.profile) ?? "", field.label);
      if (profileId && profileId !== savedId) return null;
    }

    // A saved answer only helps if this control can actually hold it. For a
    // choice field, insist the answer resembles one of the offered options —
    // otherwise the write fails and the field is reported filled when it isn't.
    // A control still waiting on its parent has no options to compare against
    // yet, so it is judged later, when it has some.
    if (field && (field.kind === "select" || field.kind === "radio") &&
        field.el?.tagName === "SELECT" && M.hasRealOptions(field.el)) {
      const choices = Array.from(field.el.options || []).map((o) => M.normalizeChoiceText(o.textContent));
      const answer = M.normalizeChoiceText(best.answer);
      const usable = choices.some((o) => o && (o === answer || o.includes(answer) || answer.includes(o)));
      if (!usable) return null;
    }

    /**
     * The same test for radio and checkbox groups.
     *
     * It only ever covered <select>, so a saved answer from a portal offering
     * different wording was written into a group that had no such option: the
     * write silently failed and the field was reported filled while still
     * blank. A group whose options haven't rendered yet is left alone and
     * judged later, when it has some.
     */
    if (field && (field.kind === "radio" || field.kind === "checkbox")) {
      let choices = [];
      try { choices = Array.from(optionTextsForField(field)); } catch {}
      if (choices.length > 1) {
        const answer = M.normalizeChoiceText(best.answer);
        const usable = choices.some((raw) => {
          const o = M.normalizeChoiceText(raw);
          return o && answer && (o === answer || o.includes(answer) || answer.includes(o));
        });
        if (!usable) return null;
      }
    }
    return best;
  }

  /* ================================================================== */
  /*  Writing a value                                                    */
  /* ================================================================== */

  /**
   * Marks a control as ours so the capture listeners don't call it a user edit.
   *
   * The mark has to cover the whole choice group. A radio group is filled by
   * clicking whichever option matches, which is usually *not* the element the
   * field is anchored to — so marking the anchor alone left the clicked option
   * unguarded, its own change listener treated Zapply's click as a person
   * answering, and the answer just replayed from Saved Answers was immediately
   * offered back as a new unsaved answer. Every fill re-queued everything it
   * had filled.
   */
  const PROGRAMMATIC_LEDGER_TTL = 15_000;

  function provenanceKey(field, answer) {
    let question = "";
    try { question = primaryQuestion(field); } catch {}
    const q = answerKey(question || field?.label || field?.el?.name || field?.el?.id || "");
    const a = answerKey(Array.isArray(answer) ? answer.join(", ") : String(answer ?? ""));
    return q && a ? `${q}::${a}` : "";
  }

  function rememberProgrammaticAnswer(field, answer) {
    const key = provenanceKey(field, answer);
    if (!key) return;
    state.programmaticAnswers.set(key, { answer: String(answer ?? ""), expiresAt: Date.now() + PROGRAMMATIC_LEDGER_TTL });
    // Keep the ledger tiny even on long-lived application tabs.
    if (state.programmaticAnswers.size > 300) {
      const now = Date.now();
      for (const [k, v] of state.programmaticAnswers) {
        if (v.expiresAt <= now) state.programmaticAnswers.delete(k);
      }
    }
  }

  function isKnownProgrammaticAnswer(field, answer) {
    const key = provenanceKey(field, answer);
    if (!key) return false;
    const hit = state.programmaticAnswers.get(key);
    if (!hit) return false;
    if (hit.expiresAt <= Date.now()) {
      state.programmaticAnswers.delete(key);
      return false;
    }
    return true;
  }

  function clearProgrammaticAnswer(field, answer) {
    const key = provenanceKey(field, answer);
    if (key) state.programmaticAnswers.delete(key);
  }

  function eachInGroup(el, fn) {
    let members = [el];
    try { members = groupMembersOf(el) || [el]; } catch {}
    if (!members.includes(el)) members = [el, ...members];
    for (const member of members) {
      try { fn(member); } catch {}
    }
  }

  function beginProgrammatic(el) {
    eachInGroup(el, (member) => {
      member.__zapplyProgrammatic = true;
      member.__zapplyProgrammaticUntil = Date.now() + 1500;
    });
  }
  function endProgrammatic(el) {
    eachInGroup(el, (member) => { member.__zapplyProgrammatic = false; });
  }
  function isProgrammatic(el) {
    return Boolean(el.__zapplyProgrammatic) || (el.__zapplyProgrammaticUntil ?? 0) > Date.now();
  }

  /**
   * Is Zapply currently writing anywhere in this control's group?
   *
   * Marking the group when a write begins is not enough on its own, because the
   * order in which a group's members are planned and filled decides which of
   * them carries the mark: filling the "Yes" radio commits its answer by
   * clicking "Prefer not to say", and if that member is filled later in the
   * pass it has not been marked yet when the click lands on it. Its change
   * listener then read Zapply's own click as the applicant answering, and the
   * answer just replayed out of Saved Answers was offered straight back as a
   * new unsaved one — so every fill re-queued everything it had filled.
   *
   * Asking the whole group removes the ordering from the question entirely.
   */
  function isGroupProgrammatic(el) {
    if (isProgrammatic(el)) return true;
    let members = [];
    try { members = groupMembersOf(el) || []; } catch { return false; }
    return members.some((member) => member !== el && isProgrammatic(member));
  }

  /** A real interaction hands the whole group back to the applicant. */
  function releaseGroupToUser(el) {
    let members = [el];
    try { members = groupMembersOf(el) || [el]; } catch {}
    if (!members.includes(el)) members = [el, ...members];
    for (const member of members) {
      member.__zapplyProgrammatic = false;
      member.__zapplyProgrammaticUntil = 0;
    }
  }

  /**
   * Did the site actually accept the value? This is what stops Zapply saying
   * "filled" while the ATS still shows "This field is required".
   */
  function verifyField(field, expected) {
    const el = field.el;
    if (field.kind === "file") return Boolean(el.files?.length);
    if (M.valuesEquivalent(el, expected, field.label)) return true;

    // Text controls reformat as you type (phone masks, date pickers), so an
    // exact match is too strict here — containment either way is enough.
    if (["text", "textarea", "email", "tel", "url", "number", "date", "month"].includes(field.kind)) {
      const actual = M.norm(el.value ?? el.textContent ?? "");
      const want = M.norm(expected);
      if (!actual || !want) return false;
      if (actual === want) return true;
      const digitsOnly = (s) => s.replace(/\D+/g, "");
      if (digitsOnly(want).length >= 4 && digitsOnly(actual) === digitsOnly(want)) return true;
      return want.length >= 3 && (actual.includes(want) || want.includes(actual));
    }
    return false;
  }

  /**
   * Has this control already been written during the pass now running?
   *
   * The rest of the engine decides "is this done?" by reading the value back,
   * which works right up until a widget renders its answer somewhere nothing
   * can read — and then a finished field looks blank and gets filled, retried
   * and re-answered. This is the backstop for that whole class of widget: once
   * a setter reports it committed something, this pass is finished with the
   * control, whatever reading it back suggests. It is scoped to one run, so a
   * deliberate second click can still have another go at a field that really
   * did stay empty.
   */
  function writtenThisRun(el) {
    return el.__zapplyWrittenRun === state.runId;
  }

  /**
   * Writes one value into one control, once.
   *
   * The only retry here is for plain text inputs, where a second write costs
   * nothing and controlled React inputs occasionally swallow the first. Custom
   * dropdowns are deliberately never retried at this level — setComboboxValue
   * already searches, filters and drills inside a single opening, and calling
   * it twice is exactly what produced the visible open/close flicker.
   */
  async function applyValue(field, value, rule) {
    const el = field.el;

    // Preserve a user-owned value, but allow an explicitly cleared control to
    // be populated again on the next manual Autofill pass.
    if (el.__zapplyUserEdited && M.hasValue(el)) return false;
    if (el.__zapplyUserEdited && !M.hasValue(el)) {
      el.__zapplyUserEdited = false;
      el.__zapplyProgrammatic = false;
      el.__zapplyProgrammaticUntil = 0;
    }
    if (!document.contains(el)) return false;
    // Already answered by this pass. Opening the same dropdown again cannot
    // improve the answer and is precisely what the user sees as autofill
    // "going back and editing the fields it just completed".
    if (writtenThisRun(el)) return true;

    beginProgrammatic(el);
    const quirks = state.adapter?.quirks ?? {};
    let ok = false;

    try {
      if (field.kind === "select") {
        ok = el.tagName === "SELECT"
          ? M.setSelectValue(el, value, rule?.options, field.label)
          : await M.setComboboxValue(el, value, quirks.dropdownDelay ?? 900, rule?.options, field.label);
      } else if (field.kind === "radio") {
        ok = M.setRadioValue(el, value, rule?.options, field.label);
      } else if (field.kind === "checkbox") {
        ok = M.setCheckboxValue(el, value, rule?.options, field.label);
      } else if (field.kind === "file") {
        /**
         * An attachment is only ever set through DataTransfer, and only when
         * the applicant has switched attachments on. The file dialog is never
         * opened — a résumé chooser appearing over the form during a fill is
         * not something the applicant asked for.
         */
        ok = state.session?.settings?.autoAttachResume === true && M.setFileValue(el, value);
      } else {
        ok = M.setTextValue(el, String(value));
        if (!ok) { await sleep(60); ok = M.setTextValue(el, String(value)); }
      }
    } catch {
      ok = false;
    }

    await sleep(40);
    // The setter reported that it committed a value. Even if we cannot read it
    // back, the control has been interacted with and must not be touched again
    // in this pass.
    if (ok) {
      el.__zapplyWrittenRun = state.runId;
      // Kept so the settle pass can put the value back if the page throws it
      // away while finishing its own rendering.
      try {
        // `readable` records whether the value could be read back straight after
        // the write. A widget we cannot read is indistinguishable from one the
        // page cleared, so restoring it would just re-open the same dropdown on
        // every settle pass — visible flicker for a result that cannot change.
        let readable = false;
        try { readable = M.hasValue(el); } catch {}
        (state.applied ??= new Map()).set(el, { field, value, rule, readable });
      } catch {}
      // Remembered so the answer sweep can tell our own writing apart from the
      // applicant's. Without it, every field Zapply filled would be queued as
      // though they had answered it by hand. Recorded on every member of a
      // choice group, because the option actually clicked is rarely the element
      // the field is anchored to.
      const written = typeof value === "object" ? null : String(value);
      let settled = "";
      try { settled = String(readValue(field) ?? "").trim(); } catch {}
      eachInGroup(el, (member) => {
        member.__zapplyWrittenValue = written;
        // The sweep compares against this to decide whether a value changed. A
        // fill is a change it must not read as the applicant answering, so the
        // baseline moves with the write.
        member.__zapplyBaselineValue = settled;
        // A fill is not an edit. Clearing this stops a later blur on a control
        // Zapply just wrote from banking the value it wrote.
        member.__zapplyUserEdited = false;
      });
      // DOM nodes are disposable on modern ATS pages. Keep provenance by
      // question+answer as well, so a trusted trailing event on a freshly
      // rendered node cannot turn our own fill into a pending manual answer.
      rememberProgrammaticAnswer(field, value);
    }

    // Each setter self-verifies; verifyField is an independent second opinion.
    // A field counts as filled when the strict check passes, or when the setter
    // succeeded and the control now visibly holds something.
    const verified = verifyField(field, value);
    const filled = verified || (ok && M.hasValue(el));
    setTimeout(() => endProgrammatic(el), 0);
    return Boolean(filled);
  }

  function collectRequiredErrors() {
    const nodes = Array.from(document.querySelectorAll(
      '[aria-invalid="true"], .error, .field-error, [class*="error"], [data-automation-id*="error"], [role="alert"]'
    ));
    return nodes.filter((n) => {
      const text = (n.textContent || "").trim();
      return text && /required|please select|please enter|invalid|must be/i.test(text) && n.getBoundingClientRect().height > 0;
    }).map((n) => (n.textContent || "").trim()).slice(0, 30);
  }

  /* ================================================================== */
  /*  Planning — decide every value before touching the page             */
  /* ================================================================== */

  /**
   * Returns what this field should contain, and where the answer came from,
   * without writing anything. Doing the whole form's thinking first is what
   * lets the write phase be a single uninterrupted sweep.
   */
  function planField(field, profile, settings) {
    const { el, label, kind } = field;

    // A non-empty field that the applicant edited is theirs and must never be
    // overwritten on a later Fill click. If they explicitly cleared it, however,
    // the field is empty again and should be eligible for Autofill on that next
    // explicit click.
    if (el.__zapplyUserEdited && M.hasValue(el)) return { status: "skipped" };
    if (el.__zapplyUserEdited && !M.hasValue(el)) {
      el.__zapplyUserEdited = false;
      el.__zapplyProgrammatic = false;
      el.__zapplyProgrammaticUntil = 0;
    }

    // Written a moment ago by this same pass. Nothing that happens later in the
    // run — a re-scan, a reconcile, the AI pass — may plan it a second time.
    if (writtenThisRun(el)) return { status: "already", key: field.rule?.key ?? null };

    // An answered question is finished. Zapply does not second-guess a value
    // that is already in the form — whether the applicant typed it, the portal
    // prefilled it, or an earlier run put it there. Running autofill again
    // therefore only ever fills what is still blank.
    if (kind !== "file" && M.hasValue(el) && settings?.overwriteExisting !== true) {
      return { status: "already", key: field.rule?.key ?? null };
    }

    const rule = field.rule;
    const canReuse = settings?.reuseSavedResponses !== false && kind !== "file";

    // A field the rule table says has no answer for an applicant — "Employee ID
    // (if applicable)" is the standing example. Returning early keeps it away
    // from saved answers and the AI pass as well as from the profile, which is
    // the only way it stays genuinely blank.
    if (rule?.blank) return { status: "skipped", key: rule.key };

    /**
     * A saved answer to *this exact question* normally outranks a derived one —
     * it is the applicant's own wording. But not when the profile already
     * answers the field.
     *
     * The queue is the part of the system that gets poisoned. A corrupted
     * Suffix banked off an Oracle form came back on every later application and
     * beat the profile every time, so correcting the profile changed nothing and
     * the applicant had no way to win. Where the profile has a value it is the
     * answer; saved answers cover the questions the profile does not know about.
     */
    const saved = canReuse ? findSavedAnswer(field) : null;
    let profileValue;
    if (rule) {
      try { profileValue = rule.value(profile, el, label, field.index ?? 0); } catch { profileValue = null; }
    }
    const profileAnswers = Boolean(profileValue) && profileValue !== "__RESUME__" && profileValue !== "__COVER_LETTER__";

    // An explicit Saved Answer is the applicant's stored decision for this
    // question. It must win over a generic/profile-derived default (for example,
    // a saved "8" years of experience should not be replaced by a calculated
    // profile value). Identity/contact/profile-only fields remain protected below.
    const profileOnly = Boolean(rule?.profileOnly);
    const protectedIdentity =
      Boolean(rule?.identity && !rule?.eeo) ||
      /\b(e-?mail|phone|mobile|telephone|country\s*code|area\s*code|extension|first\s*name|last\s*name|middle\s*name|full\s*name|date\s*of\s*birth|address\s*line|postal|zip\s*code)\b/i
        .test(String(field?.label ?? "").split("|")[0]);

    if (saved?.answer && !profileOnly && !protectedIdentity) {
      return { status: "fill", key: "saved-answer", value: saved.answer, rule, source: "saved" };
    }

    if (rule) {
      const value = profileValue;

      if (value === "__RESUME__" || value === "__COVER_LETTER__") {
        // Documents are attached only when the applicant has asked for that.
        // Silently pushing a résumé into whatever file input a page exposes is
        // not something an autofill should decide on its own.
        if (kind !== "file") return { status: "skipped", key: rule.key };
        // "unmatched" here used to mean the same thing it means everywhere
        // else: dashed-outline the field and count it in the on-page "N
        // fields need your answer" pill. For a resume/cover-letter field with
        // the toggle off that isn't a gap to flag — it's the applicant's
        // standing choice not to have Zapply touch attachments — so with the
        // toggle off this is now a silent "skipped" like any other field
        // Zapply deliberately leaves alone. It only becomes "unmatched" (and
        // worth surfacing) once the toggle is on and there is genuinely no
        // document to attach.
        if (settings?.autoAttachResume !== true) return { status: "skipped", key: rule.key };
        const wantKind = value === "__RESUME__" ? "resume" : "coverLetter";
        const docs = profile.documents ?? [];
        const doc = docs.find((d) => d.kind === wantKind && d.isDefault) || docs.find((d) => d.kind === wantKind);
        if (!doc) return { status: "unmatched", key: rule.key };
        return { status: "fill", key: rule.key, value: doc, rule, source: "profile" };
      }

      if (value) return { status: "fill", key: rule.key, value, rule, source: "profile" };

      /**
       * A field whose only legitimate source is the profile. If the profile
       * does not have it, it stays empty — no saved answer from a different
       * application, no generated sentence. See `experienceLocation`.
       */
      if (rule.profileOnly) return { status: "skipped", key: rule.key };

      // No profile value: a close saved answer is the next best source.
      if (saved?.answer) {
        return { status: "fill", key: "saved-answer", value: saved.answer, rule, source: "saved" };
      }

      // Voluntary self-identification. Declining is a permitted answer, but it
      // is still an answer the applicant did not give, so it is opt-in and off
      // by default. Without it the question is left blank for them.
      if (rule.eeo && rule.decline && settings?.eeoFallbackDecline === true) {
        return { status: "fill", key: rule.key, value: rule.decline, rule, source: "decline" };
      }

      return { status: "unmatched", key: rule.key };
    }

    if (saved?.answer) {
      return { status: "fill", key: "saved-answer", value: saved.answer, rule: null, source: "saved" };
    }

    // Nothing known. The field stays empty — a guess on a real application is
    // worse than a blank the applicant can see and fill in.
    return { status: "unmatched" };
  }

  /* ================================================================== */
  /*  Premium                                                            */
  /* ================================================================== */

  async function pickProfile(session, meta) {
    const profiles = session.profiles ?? [];
    if (!session.premium || profiles.length < 2) return { profile: session.profile, scoring: null };

    const res = await send({
      type: "ZAPPLY_SCORE",
      payload: { jobTitle: meta.jobTitle, company: meta.company, jobDescription: meta.description },
    });
    if (!res?.ok || !res.data?.best) return { profile: session.profile, scoring: null };

    const best = profiles.find((p) => p._id === res.data.best.profileId);
    if (!best) return { profile: session.profile, scoring: null };

    return {
      profile: best,
      scoring: { score: res.data.best.score, reason: res.data.best.reason, label: best.label },
    };
  }

  /**
   * Premium — answers everything the profile and saved answers couldn't cover.
   *
   * Returns why it did nothing as well as how much it drafted. Silence was the
   * problem before: with the setting off, or on a free plan, or with the API
   * key missing, the pass returned 0 and the applicant was told only that some
   * fields "need you" — with no hint that the feature existed or why it had not
   * run. The reason is reported so the popup can say which of those it was.
   */
  /**
   * Questions the model must never be asked.
   *
   * A voluntary self-identification block is the worst possible place for a
   * generated answer: every field in it is a factual declaration on a federal
   * form, and the model has the disability question sitting in its context when
   * it reads the neighbouring "Name" box. That is exactly what happened — the
   * Name field came back "Yes" and Employee ID came back with the applicant's
   * name. Both are now unreachable, three ways over:
   *
   *   - any rule marked `identity` (names, contact details, dates, all EEO);
   *   - any field whose label mentions self-identification, whatever it matched;
   *   - any choice control inside a self-identification section.
   *
   * These questions are answerable from the profile or not at all.
   */
  const SELF_ID_LABEL_RE =
    /(voluntary\s+self[-\s]?identification|self[-\s]?identification\s+of\s+disability|form\s*cc-?305|cc-?305|section\s*503|omb\s*control\s*number\s*1250|voluntary\s+disclosure|equal\s+employment\s+opportunity|eeo)/i;

  function offLimitsToAi(field) {
    if (field.rule?.identity || field.rule?.eeo || field.rule?.blank) return true;
    if (SELF_ID_LABEL_RE.test(field.label || "")) return true;
    try {
      const section = M.visibleText(field.el.closest("fieldset, section, [role='group']"));
      if (section && SELF_ID_LABEL_RE.test(section)) return true;
    } catch {}
    return false;
  }

  async function answerRemaining(session, meta, settings) {
    if (settings.aiAnswers !== true) return { drafted: 0, skipped: "off" };
    if (!session.premium) return { drafted: 0, skipped: "premium" };

    const targets = state.unmatched
      .filter((f) =>
        f.kind !== "file" &&
        !M.hasValue(f.el) &&
        !f.el.__zapplyUserEdited &&
        // Never let the model rewrite a question this pass has already
        // answered from the profile or the applicant's own saved answers.
        !writtenThisRun(f.el) &&
        !offLimitsToAi(f) &&
        document.contains(f.el))
      .filter((f) => {
        if (f.kind === "select" || f.kind === "radio" || f.kind === "checkbox") return true;
        const q = f.label.split(" | ")[0].trim();
        // A keyword list used to decide this, so a genuinely open question the
        // list happened not to name — "Tell me about a time…", "Please provide
        // a brief summary" — was skipped by the one pass meant to catch it.
        // Any labelled question is now attempted; the model is instructed to
        // answer only from the profile, and returns nothing when it can't.
        if (q.length < 4 || q.length > 300) return false;
        return true;
      })
      .slice(0, 60);

    if (!targets.length) return { drafted: 0, skipped: null };

    let done = 0;
    let failed = 0;
    let error = null;
    /**
     * Ask for several answers at once.
     *
     * Every question used to wait for the one before it to come back, so a form
     * with eight of them spent eight round trips end to end — most of the wait
     * was the network sitting idle. The requests now overlap in small groups
     * while the writing stays strictly in page order, which is what keeps one
     * answer from landing in the wrong box.
     *
     * Kept small deliberately: a wide fan-out would race the answer service's
     * own rate limits and turn a slow fill into a failed one.
     */
    const AI_BATCH = 4;
    const prefetch = new Map();

    const requestFor = (field) => {
      if (prefetch.has(field)) return prefetch.get(field);
      const promise = (async () => {
        const options = await optionsFor(field);
        return {
          options,
          res: await send({
            type: "ZAPPLY_ANSWER",
            payload: {
              question: field.label,
              options,
              jobTitle: meta.jobTitle,
              company: meta.company,
              jobDescription: meta.description?.slice(0, 3000),
              profileId: state.profile?._id,
              maxWords: field.kind === "textarea" ? 130 : 40,
              fieldType: field.kind,
              multiple: field.kind === "checkbox" && options.length > 1,
            },
          }),
        };
      })();
      prefetch.set(field, promise);
      return promise;
    };

    for (let i = 0; i < targets.length; i++) {
      const field = targets[i];
      if (state.stopRequested) break;

      // Keep the next few requests in flight while this one is being written.
      for (let ahead = i; ahead < Math.min(targets.length, i + AI_BATCH); ahead++) {
        const next = targets[ahead];
        if (!writtenThisRun(next.el) && !next.el.__zapplyUserEdited) requestFor(next);
      }

      // Re-checked here, not just when the list was built: answering an earlier
      // question can cascade a value into a later one.
      if (writtenThisRun(field.el) || M.hasValue(field.el) || field.el.__zapplyUserEdited) continue;

      const { res } = await requestFor(field);
      if (!res?.ok) {
        // A refused key, an expired plan or a rate limit fails identically for
        // every remaining question, so stop rather than spend the rest of the
        // form rediscovering it — and keep the reason to show the applicant.
        failed++;
        error = res?.error || "The answer service didn't respond.";
        if (failed >= 3) break;
        continue;
      }
      if (!res.data?.answer) continue;

      let answer = res.data.answer;
      if (field.kind !== "checkbox") answer = String(answer).trim();
      else if (typeof answer === "string") {
        try { answer = JSON.parse(answer); } catch { /* comma-separated fallback */ }
      }

      // On a menu, a drafted answer is only usable if it is one of the choices
      // actually on offer. Anything else gets fuzzily matched onto whichever
      // option scores best, which is how a question ends up confidently
      // answered with something the applicant never would have picked. A blank
      // they can see and fill in is the better outcome.
      if (!answerFitsOptions(field, answer) || !answerFitsFormat(field, answer)) {
        state.unmatched.includes(field) || state.unmatched.push(field);
        mark(field.el);
        continue;
      }

      const ok = await applyValue(field, answer, null);

      if (ok) {
        done++;
        state.drafted.add(field.el);
        field.el.classList.remove("zapply-needs-you");
        field.el.classList.add("zapply-drafted");
        flash(field.el);
      }
      await M.waitForMenusClosed(400);
    }
    return { drafted: done, skipped: done ? null : (error ? "error" : null), error };
  }

  /**
   * Remove only exact duplicate profile jobs before sizing/filling repeated
   * Work Experience blocks. Resume/profile imports can contain the same job
   * twice; treating those as two distinct rows makes the extension deliberately
   * create a duplicate experience section. We compare all meaningful job data,
   * so two genuinely different roles at the same employer are preserved.
   */
  function profileForAutofill(profile) {
    if (!profile || !Array.isArray(profile.experience)) return profile;
    const seen = new Set();
    const experience = profile.experience.filter((job) => {
      const key = [
        job?.company, job?.title, job?.location, job?.locationType,
        job?.employmentType, job?.startDate, job?.endDate, job?.current,
        job?.description,
      ].map((v) => String(v ?? "").trim().toLowerCase()).join("\u001f");
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
    return { ...profile, experience };
  }

  /* ================================================================== */
  /*  The run                                                            */
  /* ================================================================== */

  async function run({ manual = false } = {}) {
    /**
     * Autofill has exactly one entry point: a person pressing Fill. There is no
     * longer an `auto` path — see `boot()` — so anything reaching here without
     * a click, including a page mutation or a reload, is refused.
     */
    if (!manual) return { ok: false, error: "manual-start-required" };
    if (state.filling) return { ok: false, error: "Already filling." };

    state.stopRequested = false;
    state.manualSessionActive = true;
    state.completedRun = false;
    // A fresh pass. Anything written by the previous one is fair game again if
    // it somehow ended up empty, but nothing written by *this* one will be.
    state.runId++;

    /**
     * A manual Fill click is an explicit request for the latest profile/settings/
     * Saved Answers state. Never start from a stale cached response list: a user
     * can press Sync in the popup and immediately press Fill on the application,
     * and that click must see the newly synced answers.
     */
    let session = await loadSession(true);
    if (session) state.session = session;
    if (session?.profile) {
      state.profile = null;
      state.scoring = null;
    }
    if (!session?.profile) {
      overlay.show({ tone: "warn", title: "Not connected", body: "Open the Zapply popup and pair with your dashboard." });
      return { ok: false, error: "not-connected" };
    }
    if (isExcluded(session.settings)) return { ok: false, error: "excluded" };

    state.filling = true;
    watchOnFocus();
    document.documentElement.classList.add("zapply-running");
    const started = performance.now();

    const result = { filled: 0, failed: 0, unmatched: 0, detected: 0, keys: [] };

    try {
      const adapter = state.adapter ?? (state.adapter = ATS.detect());
      const settings = session.settings ?? {};
      const meta = ATS.readJobMeta(adapter);

      // The account step is not the application. Passwords are never invented
      // and are only restored from the Saved Answers entry named "Password".
      const authPage = authPageReason();

      if (!state.profile) {
        const picked = await pickProfile(session, meta);
        state.profile = picked.profile;
        state.scoring = picked.scoring;
      }
      const profile = profileForAutofill(state.profile ?? session.profile);
      // Keep the sanitized profile local to this fill. The dashboard/profile
      // record is never mutated; exact duplicate roles are simply not treated
      // as separate ATS rows during autofill.

      if (authPage) {
        // Only the email/username and the user's saved "Password" answer are
        // restored here. There is no separate password field or local fallback.
        M.beginFillSession();
        const emailField = collectFields(adapter).find((f) => f.rule?.key === "email");
        if (emailField && !M.hasValue(emailField.el)) {
          const plan = planField(emailField, profile, session.settings ?? {});
          if (plan.status === "fill") {
            try {
              if (await applyValue(emailField, plan.value, plan.rule)) {
                result.filled = 1;
                result.keys.push("email");
              }
            } catch {}
          }
        }

        // Passwords come only from the user's Saved Answers entry named
        // "Password". There is deliberately no separate browser-local fallback.
        const savedPassword = resolveSavedPassword();
        const accountSettings = await getAccountSettings();
        if (savedPassword) {
          const pwFilled = fillAccountPasswordFields(savedPassword);
          if (pwFilled) {
            result.filled += pwFilled;
            result.keys.push("password");

            if (accountSettings.zapplyAutoSubmitAccount !== false) {
              result.autoSubmitted = await submitAccountWhenReady();
              if (!result.autoSubmitted) {
                result.accountSubmitBlocked = true;
              }
            }
          }
        }

        result.skipped = authPage;
        // Reported under its own name too. `skipped` is what the popup reads
        // and is kept as-is, but "skipped" says nothing about *which* step this
        // was, so anything else asking has to string-match a field named for a
        // different question.
        result.authPage = authPage;
        result.detected = 0;
      }

      // A tiny pause between writes keeps controlled components in sync without
      // being visible. Dropdowns supply their own, longer, settle time.
      const delay = Math.min(120, Math.max(0, Number(settings.fillDelayMs ?? 45)));
      let fields = [];

      if (!authPage) {
      // Remember what the page already shows that merely looks like an open
      // menu, so the engine never waits on — or tries to close — the site's own
      // navigation or styled lists.
      M.beginFillSession();

      await M.closeOpenMenu();

      fields = collectFields(adapter);
      state.allFields = fields;
      state.unmatched = [];
      result.detected = fields.length;

      /* ---- Phase 1: plan everything, write nothing ---- */
      const plans = new Map();
      const pending = [];      // dependent controls — decided after their parent
      for (const field of fields) {
        // A control with no real choices yet cannot be planned: its options
        // arrive only once the field it depends on has been answered.
        if (isAwaitingParent(field)) { pending.push(field); continue; }
        const plan = planField(field, profile, settings);
        plans.set(field, plan);
        if (plan.status === "unmatched") {
          state.unmatched.push(field);
          mark(field.el);
        }
      }

      /* ---- Phase 2: one write per field ----
         Simple controls go first so the form visibly fills straight away, then
         the dropdowns are worked through strictly one at a time. */
      const queue = fields.filter((f) => plans.get(f)?.status === "fill");
      const simple = queue.filter((f) => !isMenuField(f));
      const menus = queue.filter((f) => isMenuField(f));
      const failed = [];
      const waiting = [];

      const write = async (field, { allowDefer = true } = {}) => {
        const plan = plans.get(field);
        if (!plan || plan.status !== "fill") return;
        if (!document.contains(field.el)) return;

        // Hold back a dropdown whose parent has not been answered yet.
        if (allowDefer && isAwaitingParent(field)) { waiting.push(field); return; }

        // Never start a dropdown while another menu is still on screen.
        if (isMenuField(field)) await M.waitForMenusClosed(600);

        let ok = false;
        try { ok = await applyValue(field, plan.value, plan.rule); } catch { ok = false; }

        if (ok) {
          result.filled++;
          if (plan.key) result.keys.push(plan.key);
          field.el.classList.remove("zapply-needs-you");
          flash(field.el);
          if (plan.source === "decline") field.el.classList.add("zapply-drafted");
        } else if (!failed.includes(field)) {
          failed.push(field);
        }
        if (delay) await sleep(delay);
      };

      for (const field of [...simple, ...menus]) {
        if (state.stopRequested) break;
        await write(field);
      }

      // Dependent controls now have their real choices: a State list exists
      // because Country was answered a moment ago, and "Please specify" has a
      // source list because "How did you hear about us?" does. Plan them now,
      // against the options they actually offer.
      const dependents = [...pending, ...waiting];
      if (dependents.length && !state.stopRequested) {
        await sleep(280);
        for (const field of dependents) {
          if (state.stopRequested) break;
          if (!document.contains(field.el)) continue;
          const plan = planField(field, profile, settings);
          plans.set(field, plan);
          if (plan.status === "fill") {
            await write(field, { allowDefer: false });
          } else if (plan.status === "unmatched" && !state.unmatched.includes(field)) {
            state.unmatched.push(field);
            mark(field.el);
          }
        }
      }

      await M.closeOpenMenu();

      /* ---- Extra rows, only for sections that actually answered ----
         These used to be created before anything was written, from the number
         of entries in the profile alone. On a Greenhouse form whose School,
         Degree and Discipline pickers can't be driven, that produced block after
         block of empty "Select..." rows — added, never filled, and left for the
         applicant to delete. A row is now created only after the first one of
         its kind has actually been answered, so a section that cannot be filled
         never grows beyond the one row the page came with. The new rows are
         picked up as fresh fields by the reconcile pass below. */
      if (!state.stopRequested) {
        const answered = new Set(result.keys);
        const kinds = [];
        if ([...EXPERIENCE_KEYS].some((k) => answered.has(k))) kinds.push("experience");
        if ([...EDUCATION_KEYS].some((k) => answered.has(k))) kinds.push("education");
        if (kinds.length) {
          await ensureProfileRows(profile, adapter, kinds);
          await M.closeOpenMenu();
        }
      }

      /* ---- Phase 3: one reconcile pass ----
         Dependent controls (State after Country, questionnaires that unhide on
         an earlier answer) only exist now, and a handful of writes genuinely
         lose a race with a re-render. Both get exactly one more attempt. */
      if (!state.stopRequested) {
        await sleep(220);
        const known = new Set(fields.map((f) => f.el));
        const fresh = collectFields(adapter).filter((f) => !known.has(f.el));
        if (fresh.length) {
          fields.push(...fresh);
          state.allFields = fields;
          result.detected = fields.length;

          /*
           * A newly-created Work Experience row is collected by itself. If we
           * index that small collection in isolation, its only Company/Title
           * anchor becomes row 0 and the second profile job is copied into the
           * new row. This is the exact duplication seen on Workday: the row was
           * genuinely new, but its fields were planned as if they belonged to
           * the first job. Re-index against the complete DOM collection before
           * planning any fresh controls.
           */
          assignRowIndexes(fields, EXPERIENCE_KEYS, [
            "currentCompany", "currentTitle", "responsibilities",
          ]);
          assignRowIndexes(fields, EDUCATION_KEYS, ["school", "degree", "fieldOfStudy"]);
        }

        const retry = [
          ...fresh.filter((f) => {
            // The row indexes above are now final for this pass. Re-plan from
            // the full collection so the newly-created row reads profile[index]
            // rather than defaulting to profile[0].
            const plan = planField(f, profile, settings);
            plans.set(f, plan);
            if (plan.status === "unmatched") { state.unmatched.push(f); mark(f.el); }
            return plan.status === "fill";
          }),
          ...failed.filter((f) =>
            document.contains(f.el) &&
            !M.hasValue(f.el) &&
            !f.el.__zapplyUserEdited &&
            // The setter already committed something here; we simply cannot
            // read this widget back. Trying again would re-edit a finished
            // field rather than fix anything.
            !writtenThisRun(f.el) &&
            // A dropdown that opened and offered nothing usable is not worth
            // opening again — that second opening is pure visible flicker for
            // a result that cannot change.
            !f.el.__zapplyNoMatch
          ),
        ];

        for (const field of retry) {
          if (state.stopRequested) break;
          const plan = plans.get(field);
          if (!plan || plan.status !== "fill") continue;
          if (isMenuField(field)) await M.waitForMenusClosed(600);

          let ok = false;
          try { ok = await applyValue(field, plan.value, plan.rule); } catch { ok = false; }

          if (ok) {
            result.filled++;
            if (plan.key) result.keys.push(plan.key);
            field.el.classList.remove("zapply-needs-you");
            flash(field.el);
          } else if (!state.unmatched.includes(field)) {
            result.failed++;
            state.unmatched.push(field);
            mark(field.el);
          }
          if (delay) await sleep(delay);
        }

        // Anything that failed twice is the user's to answer, not a silent loss.
        for (const field of failed) {
          if (!state.unmatched.includes(field) && document.contains(field.el) && !M.hasValue(field.el)) {
            state.unmatched.push(field);
            mark(field.el);
          }
        }
      }

      await M.closeOpenMenu();
      state.unmatched = Array.from(new Set(state.unmatched)).filter((f) => document.contains(f.el) && !M.hasValue(f.el));
      result.unmatched = state.unmatched.length;

      if (state.stopRequested) {
        result.stopped = true;
        overlay.show({
          tone: "warn",
          title: `Stopped — ${result.filled} fields filled`,
          body: "Autofill stopped. You can review the form and edit fields manually.",
        });
      } else {
        /* ---- Phase 4: Premium drafts what is left ---- */
        const ai = await answerRemaining(session, meta, settings);
        result.drafted = ai.drafted;
        result.aiSkipped = ai.skipped;
        result.aiError = ai.error ?? null;
        if (result.drafted) {
          result.filled += result.drafted;
          state.unmatched = state.unmatched.filter((f) => !M.hasValue(f.el));
          result.unmatched = state.unmatched.length;
        }

        await sleep(180);
        result.validationErrors = collectRequiredErrors();
        // A validation message means something on this page still needs an
        // answer, so surface the empty fields — but only the empty ones. The
        // old build re-queued every field on the page, which is why the count
        // in the pill was always alarming and mostly wrong.
        if (result.validationErrors.length) {
          for (const field of fields) {
            if (field.kind === "file") continue;
            if (!document.contains(field.el)) continue;
            if (!M.hasValue(field.el) && !state.unmatched.includes(field)) {
              state.unmatched.push(field);
              mark(field.el);
            }
          }
          result.unmatched = state.unmatched.length;
        }
      }
      } // end if (!authPage)
    } finally {
      await M.closeOpenMenu();
      document.documentElement.classList.remove("zapply-running");
      state.filling = false;
      state.manualSessionActive = false;
      state.completedRun = true;
    }

    result.durationMs = Math.round(performance.now() - started);
    result.profileLabel = state.profile?.label ?? null;
    result.matchScore = state.scoring?.score ?? null;
    state.lastRun = result;

    watchUnmatched();
    queueAnswersFromForm();
    scheduleSettleCheck();

    const settings = state.session?.settings ?? {};
    if (settings.showOverlay !== false && result.unmatched && !result.stopped) {
      const scoreLine = state.scoring ? `Profile match: ${state.scoring.score}%. ` : "";
      overlay.show({
        tone: "partial",
        title: `${result.unmatched} field${result.unmatched === 1 ? "" : "s"} need your answer`,
        body:
          scoreLine +
          `${result.validationErrors?.length ? `${result.validationErrors.length} validation message${result.validationErrors.length === 1 ? "" : "s"} detected. ` : ""}` +
          "The highlighted questions were not safely answered.",
        // Three seconds, then out of the way. It used to stay until dismissed,
        // which parked it over the bottom of the form — exactly where the
        // remaining questions are. The fields themselves stay highlighted, so
        // nothing is lost when the pill goes.
        autoHide: 3000,
      });
    } else if (!result.stopped) {
      overlay.hide();
    }

    // One explicit click = one complete fill pass. Never click Save/Next and
    // never start another run from DOM mutations.
    return { ok: true, data: result };
  }

  /** Does filling this control involve opening a popup menu? */
  function isMenuField(field) {
    return field.kind === "select" && field.el.tagName !== "SELECT";
  }

  /* ================================================================== */
  /*  Capturing what the user answers by hand                            */
  /* ================================================================== */

  const pending = new Map();

  function queueAnswer(entry) {
    if (!entry.question || !String(entry.answer ?? "").trim()) return;
    const key = String(entry.question).trim();
    // One question, one queued answer. Several paths can legitimately report the
    // same edit — the control's own change event, a sibling in the same choice
    // group, and the sweep that re-reads everything afterwards — so the queue is
    // made idempotent here rather than relying on each of them to notice.
    // A genuinely different answer still supersedes the old one.
    const previous = pending.get(key);
    if (previous && previous.answer === entry.answer) return;
    pending.set(key, entry);
    state.captured.set(key, entry);
    // Saved Responses are not written to the database here — the user controls
    // persistence with Sync. The background worker keeps a durable local queue.
    send({ type: "ZAPPLY_QUEUE_RESPONSES", responses: [entry] });
  }

  async function flushAnswers() {
    return true;
  }

  /** Reads whatever the user has put in a field, in a comparable form. */
  function readValue(field) {
    const el = field.el;
    if (el.type === "checkbox" || el.getAttribute("role") === "checkbox") {
      const role = el.getAttribute("role");
      // M.choiceGroup resolves a group the same way everywhere. This branch used
      // to fall back to `[el]` when the boxes shared no `name`, so a three-option
      // group read as a single yes/no and the answer stored never matched the
      // options stored beside it.
      const group = M.choiceGroup(el);
      const checked = group.filter((cb) => role === "checkbox" ? cb.getAttribute("aria-checked") === "true" : cb.checked);
      if (!checked.length) return "No";
      if (group.length === 1) return "Yes";
      return checked.map((cb) => M.radioOptionText(cb)).filter(Boolean).join(", ");
    }
    if (el.type === "radio" || el.getAttribute("role") === "radio") {
      const custom = el.getAttribute("role") === "radio";
      const group = M.choiceGroup(el);
      const picked = group.find((r) => custom ? r.getAttribute("aria-checked") === "true" : r.checked);
      return picked ? M.radioOptionText(picked) : "";
    }
    if (el.tagName === "SELECT") {
      const opt = el.options[el.selectedIndex];
      return opt && opt.value ? (opt.textContent || "").trim() : "";
    }
    if (el.tagName === "BUTTON" || el.getAttribute("role") === "button" || el.getAttribute("role") === "combobox") {
      /**
       * A segmented control is answered by which segment is pressed.
       *
       * comboboxDisplayValue reads the control's own text, which for a row of
       * Yes/No buttons is the label of whichever button the field happens to be
       * anchored to — "Yes", pressed or not. It therefore never changed when
       * the applicant pressed "No", and once capture required a real change to
       * count as an edit, segmented answers stopped being recorded at all.
       */
      const segmented = M.choiceButtonGroup?.(el);
      if (segmented?.length) return M.choiceButtonGroupValue(el) || "";
      return M.comboboxDisplayValue(el);
    }
    return el.value ?? "";
  }

  /**
   * The choices a field offers. Custom dropdowns have to be opened to be read,
   * which is done through the menu registry so the menu is closed again before
   * anything else runs.
   */
  async function optionsFor(field) {
    const el = field.el;
    if (el.tagName === "SELECT") {
      return Array.from(el.options || [])
        .map((o) => (o.textContent || "").trim())
        .filter(Boolean)
        .filter((x) => !/^(select|choose|please select|--)/i.test(x))
        .slice(0, 60);
    }
    if (el.type === "radio" || el.type === "checkbox" ||
        el.getAttribute("role") === "radio" || el.getAttribute("role") === "checkbox") {
      return M.optionTextsFor(el);
    }
    if (field.kind === "select") {
      try { return await M.readComboboxOptions(el, state.adapter?.quirks?.dropdownDelay ?? 800); }
      catch { return []; }
    }
    return [];
  }

  /**
   * The question as a person would read it.
   *
   * `field.label` is several descriptions joined with " | ", ending with the
   * humanized name attribute — so answers were being stored under headings like
   * "Why are you interested in this role? | q why", which is what the dashboard
   * then displayed. The first description is the visible label, and it is also
   * the first candidate findSavedAnswer looks up, so storing it keeps the round
   * trip exact as well as readable.
   */
  /**
   * The question heading that sits above a group of choices.
   *
   * A radio or checkbox is usually wrapped in a <label> holding its *option*
   * text, so the derived label starts with "Referral" or "Evenings" — and those
   * were being stored as the question. The real question is the nearest heading
   * in the group container that isn't itself an option.
   */
  /**
   * Text that is an answer rather than a question.
   *
   * A choice group's own option labels are the single commonest thing to be
   * mistaken for its question, which is how an answer was saved under the
   * question "Prefer not to say". Anything matching this is never a question,
   * whatever else recommends it.
   */
  const ANSWER_LIKE_RE = new RegExp(
    "^(?:" +
      "yes|no|y|n|true|false|maybe|other|none|n\\/?a|not applicable|unsure|" +
      "male|female|man|woman|non[-\\s]?binary|transgender|" +
      "prefer not to (?:say|answer|disclose|respond|specify)|" +
      "i (?:do not|don't|dont) (?:wish|want|choose) to (?:answer|say|disclose|self[-\\s]?identify|specify)|" +
      "(?:i )?(?:decline|choose not|do not wish|don't wish) to (?:self[-\\s]?identify|answer|disclose|specify|state)|" +
      "declined? to self[-\\s]?identify|do not wish to disclose|" +
      /**
       * "I prefer to self-describe".
       *
       * An option on every demographic question Ashby and Greenhouse render,
       * and the one that was banked as a *question* — the humanized `id` reads
       * back as "i prefer to self describe", which the exact-match options test
       * missed because humanize() had already turned the hyphen into a space.
       * Matching it here settles it however the punctuation lands.
       */
      "(?:i )?(?:prefer|choose|wish|want|would like) (?:not )?to self[-\\s]?describe|" +
      "self[-\\s]?describe|" +
      "select(?:\\s*an?\\s*option|\\s*one)?|please select|choose(?:\\s*an?\\s*option|\\s*one)?|" +
      /**
       * A typeahead's resting prompt. Ashby's location combobox says "Start
       * typing…", which reached Saved Answers as the question for the city the
       * applicant picked.
       */
      "start typing.*|begin typing.*|type to search.*|type here.*|search\\.*|none selected|" +
      "-{2,}.*|\\u2014.*" +
    ")\\s*[.?!*]?$",
    "i"
  );

  /**
   * Every label the controls in this field's group carry.
   *
   * Built from the group members themselves rather than only from
   * `optionTextsFor`, because that helper resolves a group through the `name`
   * attribute and a great many ATS radio groups have no `name` at all. When it
   * fell back to the single anchor control, every *other* option in the group
   * looked like a legitimate question — which is exactly how "Prefer not to
   * say" became one.
   */
  /**
   * One spelling for one answer.
   *
   * The options set used to hold plain lowercased text, so membership was an
   * exact string test. `humanize()` reaches it having already replaced every
   * hyphen and underscore with a space, so the option "I prefer to
   * self-describe" and the machine name "i prefer to self describe" were two
   * different strings — the option test missed, and the option label was saved
   * as the question. Stripping punctuation on both sides removes the whole
   * class of near-miss.
   */
  function answerKey(value) {
    return String(value ?? "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, " ")
      .trim();
  }

  /**
   * Is this text an identifier the form generated, rather than words a person
   * wrote?
   *
   * `deriveLabel` ends with the humanized `name` and `id` attributes so that a
   * rule can match "firstName". On Ashby those attributes are uuids:
   * `4409827-edb-0c17-447a-b4c5-8a5afa5ba1a9_gh_quest_labeled_checkbox_2`
   * humanizes to "edb 0c17 447a b4c5 8a5afa5ba1a9 gh quest labeled checkbox 2",
   * which is long enough and unlike enough to any option that it passed every
   * test a question candidate had to pass — and that string is what the popup
   * displayed as the question, and what the answer was banked under. Banked
   * there it could never match again, because the next form's uuid is a
   * different uuid, so the applicant was asked the same question on every
   * application.
   */
  function looksMachineGenerated(text) {
    const value = String(text || "");
    if (!value) return false;

    // A uuid fragment: four or more hex characters carrying both a letter and a
    // digit. "0c17", "b4c5" and "8a5afa5ba1a9" all qualify; "2024" has no
    // letter and "cafe" has no digit, so ordinary words and years are safe.
    if (/\b(?=[0-9a-f]*[0-9])(?=[0-9a-f]*[a-f])[0-9a-f]{4,}\b/i.test(value)) return true;

    // The scaffolding ATS builders leave in `name` and `id`.
    if (/\b(?:gh[\s_-]?quest|systemfield|system[\s_-]?field|labell?ed[\s_-]?(?:checkbox|radio|select|input)|urn[\s_-]?li|data[\s_-]?automation[\s_-]?id|customfield|custom[\s_-]?field)\b/i.test(value)) {
      return true;
    }

    // A generated ordinal — "... checkbox 2", "... question 14". A real
    // question does not end by numbering its own widget.
    if (/\b(?:checkbox(?:es)?|radio|select|dropdown|input|textarea|field|question|answer|option)\s*\d+\s*$/i.test(value)) {
      return true;
    }

    return false;
  }

  /**
   * Every humanized machine name attached to this control's group.
   *
   * Kept separate so a name-derived candidate can be demoted rather than
   * banned: a bare text box whose only description is `name="notice_period"`
   * still needs "notice period" as its question, and that is a perfectly good
   * one. It just must never outrank the heading printed above a choice group.
   */
  function machineNameParts(el) {
    const out = new Set();
    const add = (value) => {
      const text = String(value ?? "").trim().replace(/\s+/g, " ").toLowerCase();
      if (text) out.add(text);
    };
    if (!el) return out;
    let members = [el];
    try { members = groupMembersOf(el) || [el]; } catch {}
    if (!members.includes(el)) members = [el, ...members];
    for (const member of members) {
      if (!member?.getAttribute) continue;
      try {
        add(M.humanize?.(member.getAttribute("name")));
        add(M.humanize?.(member.id));
      } catch {}
    }
    return out;
  }

  /**
   * A dropdown's resting row is a prompt, not a choice.
   *
   * "Start typing…" is Ashby's; the rest cover the typeaheads and native
   * selects everywhere else. Stored as a choice it padded every saved dropdown
   * answer with a fake option and showed the wrong count in the dashboard.
   */
  const PLACEHOLDER_OPTION_RE =
    /^(?:select|choose|please\s+select|pick\s+one|start\s+typing|begin\s+typing|type\s+to\s+search|type\s+here|search|none\s+selected|-{2,})\b|^[-\u2013\u2014\s\u2026.]*$/i;

  function optionTextsForField(field) {
    const out = new Set();
    const add = (value) => {
      const key = answerKey(value);
      if (key) out.add(key);
    };

    const el = field?.el;
    if (!el) return out;

    try { (M.optionTextsFor(el) || []).forEach(add); } catch {}

    if (field.kind === "radio" || field.kind === "checkbox") {
      let members = [el];
      try { members = groupMembersOf(el); } catch {}

      /**
       * A lone checkbox is its own question.
       *
       * "I agree to the terms and conditions" is what the box asks, not one of
       * several answers to something else. Treating its label as an option
       * disqualified it from being the question, so the search fell through to
       * whatever heading happened to be above it — an edit to the consent box
       * was banked under "Work Experience 2". A group of one offers no choice
       * to compare against.
       */
      if (field.kind === "checkbox" && members.length <= 1) return new Set();

      for (const member of members) {
        try {
          add(M.radioOptionText?.(member));
          add(member.getAttribute?.("aria-label"));
          add(member.getAttribute?.("value"));
          const wrapping = member.closest?.("label");
          if (wrapping) add(M.visibleText?.(wrapping) ?? wrapping.textContent);
          if (member.id) {
            const escaped = (window.CSS && CSS.escape) ? CSS.escape(member.id) : member.id;
            document
              .querySelectorAll(`label[for="${escaped}"]`)
              .forEach((l) => add(M.visibleText?.(l) ?? l.textContent));
          }
        } catch {}
      }
    }
    return out;
  }

  /** The ids of every control answering the same question as this one. */
  function groupMemberIds(el) {
    const ids = new Set();
    try { groupMembersOf(el).forEach((m) => { if (m?.id) ids.add(m.id); }); } catch {}
    return ids;
  }

  /**
   * The question a heading near this control is asking.
   *
   * `exclude` carries the group's own option labels. Without it this walked up
   * the DOM and returned the first text of eight characters or more, which on a
   * Yes / No / Prefer not to say group is "Prefer not to say" — the third
   * option, purely because the first two are too short to pass the length test.
   */
  function questionHeadingNear(el, exclude) {
    const skip = exclude instanceof Set ? exclude : new Set();
    const memberIds = groupMemberIds(el);
    const CONTROL_SEL =
      "input, select, textarea, button, [role='radio'], [role='checkbox'], [role='combobox'], [role='listbox']";

    /**
     * Is this text the label of a *different* question on the same form?
     *
     * Without this the search climbed out of its own field and read the rest of
     * the form. On an iCIMS profile block it answered "Address" with the
     * heading "How did you hear about us?" two fields further down, and the
     * saved answer for that question — "LinkedIn" — was then written into the
     * address and city boxes. A candidate is rejected when any ancestor between
     * it and the level being scanned wraps a form control but not this one:
     * that ancestor is another field's container, so the text inside it belongs
     * to another field.
     */
    const inAnotherField = (cand, stopAt) => {
      let node = cand.parentElement;
      while (node && node !== stopAt && node !== document.body) {
        if (!node.contains(el)) {
          try { if (node.querySelector(CONTROL_SEL)) return true; } catch {}
        }
        node = node.parentElement;
      }
      return false;
    };

    const readCandidate = (cand, stopAt) => {
      if (!cand || cand.contains(el)) return "";
      // A node wrapping a control is an option label, not the question.
      if (cand.querySelector(CONTROL_SEL)) return "";
      // A <label for> pointing at one of this group's own controls is an option
      // label too, even though it does not wrap it.
      const forId = cand.getAttribute?.("for");
      if (forId) {
        if (memberIds.has(forId)) return "";
        // A label aimed at some other control on the page is that control's
        // label, never this one's question.
        try { if (document.getElementById(forId) && !memberIds.has(forId)) return ""; } catch {}
      }
      if (inAnotherField(cand, stopAt)) return "";
      const text = (cand.textContent || "").trim().replace(/\s+/g, " ");
      if (text.length < 8 || text.length > 300) return "";
      if (skip.has(answerKey(text))) return "";
      if (ANSWER_LIKE_RE.test(text)) return "";
      if (looksMachineGenerated(text)) return "";
      return text;
    };

    let node = el?.parentElement;
    for (let depth = 0; node && depth < 6; depth++, node = node.parentElement) {
      if (node === document.body || node === document.documentElement) break;
      let candidates;
      try {
        candidates = node.querySelectorAll(
          'legend, [class*="question"], [class*="Question"], h2, h3, h4, h5, p, label, span, div'
        );
      } catch { break; }

      // A question mark, or a <legend>, is the form telling us outright which
      // text is the question. Anything else at this depth is only a fallback.
      let fallback = "";
      for (const cand of candidates) {
        const text = readCandidate(cand, node);
        if (!text) continue;
        if (cand.tagName === "LEGEND" || /\?\s*\*?$/.test(text)) return text;
        if (!fallback) fallback = text;
      }
      if (fallback) return fallback;
    }
    return "";
  }

  /** The accessible name of the group this control belongs to, if it has one. */
  function groupAccessibleNames(el) {
    const names = [];
    if (!el) return names;
    const push = (value) => {
      const text = String(value ?? "").trim().replace(/\s+/g, " ");
      if (text) names.push(text);
    };
    const fromIdList = (list) => {
      String(list || "").split(/\s+/).forEach((id) => {
        if (!id) return;
        const node = document.getElementById(id);
        if (node && !node.contains(el)) push(M.visibleText?.(node) ?? node.textContent);
      });
    };

    try {
      const container = el.closest?.("fieldset, [role='radiogroup'], [role='group']");
      if (container) {
        const legend = container.querySelector("legend");
        if (legend && !legend.contains(el)) push(M.visibleText?.(legend) ?? legend.textContent);
        push(container.getAttribute("aria-label"));
        fromIdList(container.getAttribute("aria-labelledby"));
      }
      // Some portals name the question on the control instead of the group.
      fromIdList(el.getAttribute?.("aria-labelledby"));
    } catch {}
    return names;
  }

  /**
   * The question as a person would read it.
   *
   * `field.label` is several descriptions joined with " | ", ending with the
   * humanized name attribute. The first description is normally the visible
   * label — except on choice groups, where it is one of the options.
   *
   * Every candidate is now checked against the group's own option labels and
   * against a list of answer phrasings, so a dropdown, radio group or checkbox
   * group is saved under the question it asks rather than under the answer that
   * was picked.
   */
  function primaryQuestion(field, { floor = 5 } = {}) {
    const el = field?.el;
    const parts = String(field?.label ?? "").split("|").map((x) => x.trim()).filter(Boolean);
    const options = optionTextsForField(field);
    const machine = machineNameParts(el);

    const acceptable = (value) => {
      const text = String(value ?? "").trim().replace(/\s+/g, " ");
      if (text.length < floor || text.length > 300) return "";
      if (options.has(answerKey(text))) return "";
      if (ANSWER_LIKE_RE.test(text)) return "";
      if (looksMachineGenerated(text)) return "";
      return text;
    };

    /** Acceptable *and* actually printed on the page, rather than derived from an attribute. */
    const fromPage = (value) => {
      const text = acceptable(value);
      if (!text) return "";
      return machine.has(text.toLowerCase()) ? "" : text;
    };

    // 1. The group's own accessible name — a <legend>, a radiogroup's
    //    aria-label, or whatever its aria-labelledby points at. This is the
    //    form stating which text is the question, so it outranks everything.
    for (const name of groupAccessibleNames(el)) {
      const text = fromPage(name);
      if (text) return text;
    }

    const isChoice = field?.kind === "radio" || field?.kind === "checkbox" || field?.kind === "select";

    // 2. A visible label part that reads like a question rather than an answer.
    if (isChoice) {
      for (const part of parts) {
        const text = fromPage(part);
        if (text && (/\?/.test(text) || text.length > 12)) return text;
      }
    }

    // 3. Any remaining visible label part that is not one of the answers.
    for (const part of parts) {
      const text = fromPage(part);
      if (text) return text;
    }

    /**
     * 4. The heading printed above the control.
     *
     * This used to sit *below* the raw label parts for everything except a
     * choice group, and below only some of them even there — so on a form whose
     * controls are named with uuids the humanized attribute won, and the
     * question the applicant could plainly read above the boxes was never
     * consulted. The search is now reached by every field before any
     * attribute-derived text is considered.
     */
    const heading = questionHeadingNear(el, options);
    if (heading) return heading;

    /**
     * 5. Last resort: the humanized `name` or `id`.
     *
     * Still worth having — a bare text box carrying nothing but
     * `name="notice_period"` is asking about a notice period, and that is the
     * only description of it that exists. `acceptable` has already rejected the
     * uuid-shaped ones, so what reaches here reads like English.
     */
    for (const part of parts) {
      const text = acceptable(part);
      if (text) return text;
    }
    return "";
  }

  /**
   * Which repeated block this control sits in, spelled out for a person.
   *
   * The pending list is keyed by the question text, all the way through to
   * extension storage. A form with two Work Experience rows asks "Company"
   * twice, so correcting both employers produced two entries under one key and
   * the second silently replaced the first — the applicant made two edits and
   * the popup offered them one. The row is part of what makes those two
   * questions different, so it belongs in the question.
   *
   * The number is written outside any brackets on purpose: the background's
   * key normaliser strips bracketed text, so "Professional Experience (1)" and
   * "(2)" would collapse back to the same key.
   */
  function sectionQualifier(field) {
    /**
     * Only a repeated history row is qualified.
     *
     * A qualified question does not travel — "Company — Work Experience 2"
     * matches nothing on the next application, which is exactly right for a
     * positional row and exactly wrong for "What is your notice period?". So
     * this is limited to the two families that actually repeat; anything else
     * keeps its plain question and stays reusable. Two unrelated boxes that
     * still land on the same wording are separated by `uncontestedQuestion`.
     */
    const key = field?.rule?.key;
    if (!key || !(EXPERIENCE_KEYS.has(key) || EDUCATION_KEYS.has(key))) return "";

    let title = "";
    let index = null;
    try {
      const section = M.sectionContext?.(field?.el);
      title = String(section?.title ?? "").trim();
      index = section?.index;
    } catch {}

    const row = Number.isInteger(field?.index) ? field.index : index;
    if (!title) return Number.isInteger(row) && row > 0 ? `row ${row + 1}` : "";

    // "Work Experience 2" and "Professional Experience (2)" both reduce to the
    // heading's wording plus a bare number.
    const stem = title.replace(/[([{#\-–—:]*\s*\d+\s*(?:of|\/)?\s*\d*\s*[)\]}]*\s*$/, "").trim();
    if (!Number.isInteger(row)) return stem || title;
    return `${stem || title} ${row + 1}`;
  }

  /**
   * The question a manual edit is filed under.
   *
   * Separate from `primaryQuestion` because that one is also the lookup key for
   * replaying a saved answer onto the next application, and a row-qualified
   * question deliberately does not travel: "Company — Work Experience 2" means
   * nothing on a different form. What it does do is keep two edits on *this*
   * page apart, and give a two-letter label like "To" enough text to survive
   * the length floor instead of being dropped without trace.
   */
  function capturedQuestion(field) {
    const qualifier = sectionQualifier(field);
    const base = primaryQuestion(field, { floor: qualifier ? 2 : 5 });
    if (!base) return "";
    if (!qualifier) return base;
    if (base.toLowerCase().includes(qualifier.toLowerCase())) return base;
    return `${base} \u2014 ${qualifier}`;
  }

  /** Every control that answers the same question as this one. */
  function groupMembersOf(el) {
    try {
      const group = M.choiceGroup?.(el);
      if (group?.length) return group;
    } catch {}
    return [el];
  }

  /** Is the value in this control simply the one Zapply put there? */
  function matchesWritten(el, answer) {
    const written = el.__zapplyWrittenValue;
    if (written == null) return false;
    try {
      const a = M.normalizeChoiceText(String(answer));
      const b = M.normalizeChoiceText(String(written));
      if (!a || !b) return false;
      return a === b || a.includes(b) || b.includes(a);
    } catch {
      return String(answer) === String(written);
    }
  }

  /** Does this control still hold precisely the value Zapply wrote into it? */
  function sameAsWritten(el, answer) {
    const written = el.__zapplyWrittenValue;
    if (written == null) return false;
    try {
      const a = M.normalizeChoiceText(String(answer));
      const b = M.normalizeChoiceText(String(written));
      return Boolean(a) && a === b;
    } catch {
      return String(answer) === String(written);
    }
  }

  /** Was this control, or any member of its group, filled by the model? */
  function isDrafted(el) {
    const drafted = state.drafted;
    if (!drafted?.size) return false;
    if (drafted.has(el)) return true;
    try { return groupMembersOf(el).some((m) => drafted.has(m)); } catch { return false; }
  }

  /**
   * Queue whatever this control currently holds, if it is the applicant's.
   *
   * `userDriven` means an event proved a person did it. The sweep has no such
   * proof, so it additionally refuses anything that still matches what Zapply
   * wrote — otherwise re-running a fill would bank the whole form as answers.
   */
  /**
   * An answer the applicant typed is held, not banked.
   *
   * Every edit used to go straight into the sync queue. That is how a wrong
   * value became a permanent one: the AI put "Yes" in a Name box, the applicant
   * corrected it, and *both* the correction and the original were captured
   * against questions they had never knowingly saved — so the next application
   * was filled from the same bad queue. Worse, there was no moment at which
   * they were told any of it was being kept.
   *
   * An edit now lands here and stays visible as an unsaved answer until it is
   * explicitly saved. Nothing reaches Saved Answers without a click.
   */
  const pendingSave = new Map();   // question -> { entry, field }

  /**
   * Two controls, two entries — always.
   *
   * The Map and the storage behind it are both keyed by the question, and
   * `sectionQualifier` cannot always tell two boxes apart: Workday's `From` and
   * `To` each render a segment labelled only "Month", inside the same row. When
   * that happens the second edit used to overwrite the first and one of the
   * applicant's corrections simply vanished from the list. A numeric suffix is
   * added instead, so nothing is ever silently lost. Brackets are avoided
   * because the background's key normaliser strips them.
   */
  function uncontestedQuestion(field, question) {
    const held = pendingSave.get(question);
    if (!held || held.field?.el === field?.el) return question;
    for (let n = 2; n <= 20; n++) {
      const candidate = `${question} \u2014 ${n}`;
      const taken = pendingSave.get(candidate);
      if (!taken || taken.field?.el === field?.el) return candidate;
    }
    return question;
  }

  function holdAnswer(field, entry) {
    pendingSave.set(entry.question, { entry, field });
    try { field.el.classList.add("zapply-unsaved"); } catch {}
    /**
     * Held in extension storage, not in this Map.
     *
     * The Map is kept only to know which control on *this* page to outline and
     * to clear the outline when the answer is saved. It cannot be the record:
     * a Workday application navigates on every step, each navigation tears this
     * content script down, and the Map went with it — so an answer edited on
     * step 2 was gone before the applicant reached the popup. That is why
     * saving answers looked like it did nothing.
     *
     * Storage survives navigation, reload and closing the tab, and the popup
     * reads it from there, so it works even on a page where this script never
     * loaded.
     */
    send({ type: "ZAPPLY_HOLD_ANSWERS", items: [entry] });
    publishPending();
  }

  /** Nudge any open popup to re-read the held list. */
  function publishPending() {
    const items = Array.from(pendingSave.values()).map(({ entry }) => ({
      question: entry.question,
      answer: entry.answer,
      inputType: entry.inputType,
      options: entry.options,
      ats: entry.ats,
      domain: entry.domain,
    }));
    try {
      chrome.runtime.sendMessage({ type: "ZAPPLY_PENDING", items, url: location.href });
    } catch {}
  }

  function commitPendingAnswers() {
    const held = Array.from(pendingSave.values());
    for (const { field } of held) {
      try {
        field.el.classList.remove("zapply-unsaved");
        field.el.classList.add("zapply-saved");
      } catch {}
    }
    pendingSave.clear();
    // Saving is done against storage, so it covers answers held on earlier
    // steps of this application as well as the ones still on screen.
    send({ type: "ZAPPLY_SAVE_HELD" });
    publishPending();
    return held.length;
  }

  function discardPendingAnswers() {
    for (const { field } of pendingSave.values()) {
      try { field.el.classList.remove("zapply-unsaved"); } catch {}
    }
    pendingSave.clear();
    publishPending();
  }

  /**
   * Saving and discarding are now driven from the extension popup, which is
   * where the applicant can see a pending answer beside the saved ones it would
   * join. Nothing about the hold model changed: an edit is still held, and still
   * reaches Saved Answers only on an explicit action.
   */
  function handlePendingCommand(msg, respond) {
    if (msg.type === "ZAPPLY_PENDING_LIST") {
      respond({
        ok: true,
        items: Array.from(pendingSave.values()).map(({ entry }) => ({
          question: entry.question,
          answer: entry.answer,
          inputType: entry.inputType,
          domain: entry.domain,
        })),
      });
      return true;
    }
    if (msg.type === "ZAPPLY_PENDING_SAVE") {
      const saved = msg.question ? commitOne(msg.question) : commitPendingAnswers();
      respond({ ok: true, saved });
      return true;
    }
    if (msg.type === "ZAPPLY_PENDING_DISCARD") {
      if (msg.question) {
        const held = pendingSave.get(msg.question);
        if (held) { try { held.field.el.classList.remove("zapply-unsaved"); } catch {} }
        pendingSave.delete(msg.question);
        send({ type: "ZAPPLY_DISCARD_HELD", questions: [msg.question] });
        publishPending();
      } else {
        discardPendingAnswers();
        send({ type: "ZAPPLY_DISCARD_HELD" });
      }
      respond({ ok: true });
      return true;
    }
    return false;
  }

  function commitOne(question) {
    const held = pendingSave.get(question);
    if (held) {
      try {
        held.field.el.classList.remove("zapply-unsaved");
        held.field.el.classList.add("zapply-saved");
      } catch {}
      pendingSave.delete(question);
    }
    send({ type: "ZAPPLY_SAVE_HELD", questions: [question] });
    publishPending();
    return 1;
  }

  function worthSaving(field, answer) {
    const el = field.el;
    const text = String(answer ?? "");
    if (!text) return false;

    const cap = Number(el?.getAttribute?.("maxlength") ?? el?.maxLength ?? 0);
    if (cap > 0 && text.length > cap) return false;

    // The page's own verdict. If it is showing an error for this field, its
    // current contents are by definition not an answer worth reusing.
    try {
      if (el.getAttribute?.("aria-invalid") === "true") return false;
      const described = el.getAttribute?.("aria-describedby");
      if (described) {
        for (const id of described.split(/\s+/)) {
          const node = document.getElementById(id);
          const msg = node && M.visibleText(node);
          if (msg && /\b(enter a maximum|maximum of \d+|too long|invalid|must be|required)\b/i.test(msg)) return false;
        }
      }
    } catch {}

    // A short structured box holding a sentence is a box something got wrong.
    const structured = /suffix|prefix|title|initial|city|state|county|district|zip|postal|country|line\s*\d/i;
    if (structured.test(field.label || "") && (text.length > 100 || /\.\s+\S/.test(text))) return false;

    // The same fragment repeated back to back is the accumulation signature.
    if (/(\b[A-Za-z]{4,}\b)\1/.test(text.replace(/\s+/g, ""))) return false;

    return true;
  }

  /**
   * A Yes / No / Prefer-not-to-say group is a question, not a profile field.
   *
   * Rules match on wording, and a demographic question can easily contain a
   * word a profile rule watches for: "Are you the first member of your
   * immediate family to attend university?" matched the **school** rule on
   * "university". School is profile-owned, so the answer was silently refused
   * and the applicant's choice never appeared to save — while the same
   * question in different markup saved perfectly, which is what made it look
   * intermittent.
   *
   * A profile field holds a value like "Osmania University". A group whose only
   * choices are yes, no and a decline option cannot be one, whatever its
   * wording, so a profile rule has no claim on it.
   */
  function isGenericChoiceGroup(field) {
    /**
     * Dropdowns count too.
     *
     * This covered radios and checkboxes only, so the identical question drawn
     * as a <select> — which is how most ATSs draw "Are you at least 18 years of
     * age?" — kept whatever profile rule its wording happened to match, and
     * correcting the answer by hand was silently refused. The applicant saw
     * their change on the form and nothing in the unsaved list, which is the
     * "dropdown answers don't save" report.
     */
    if (field?.kind !== "radio" && field?.kind !== "checkbox" && field?.kind !== "select") return false;
    let options = [];
    try { options = M.optionTextsFor(field.el) || []; } catch { return false; }
    // The opening "Select…" row says nothing about what the question is.
    options = options.map((o) => String(o).trim()).filter((o) => o && !PLACEHOLDER_OPTION_RE.test(o));
    if (options.length < 2) return false;
    return options.every((option) => ANSWER_LIKE_RE.test(option));
  }

  /**
   * Answers that belong to the profile and must never reach Saved Answers.
   *
   * Everything else an applicant edits is fair game — a corrected employer, a
   * date, a dropdown, a radio group — and is held for review. These are not.
   * A name or an email address is edited in the profile, and banking one
   * against a question would both put it on the next application under a
   * question it does not answer and copy personal details into a reusable
   * store the applicant never asked to keep them in.
   *
   * Deliberately narrower than the old `if (field.rule) return`, which excluded
   * every field a rule had matched and is what made corrections to work history
   * and dropdown answers vanish from the pending list.
   */
  const NEVER_BANKED_KEYS = new Set([
    "firstName", "lastName", "middleName", "preferredName", "fullName", "signature",
    "namePrefix", "nameSuffix", "dateOfBirth", "email", "emailConfirm",
    "phone", "phoneCountryCode", "phoneType",
    "address", "addressLine2", "city", "state", "zip",
    "linkedin", "github", "portfolio", "twitter",
    "resume", "coverLetter",
  ]);

  const IDENTITY_LABEL_RE =
    /\b(e-?mail|first\s*name|last\s*name|middle\s*name|full\s*name|given\s*name|family\s*name|surname|date\s*of\s*birth|social\s*security|national\s*id|address\s*line|postal\s*code|zip\s*code)\b/i;

  function belongsToProfile(field) {
    const key = field?.rule?.key;
    if (key && NEVER_BANKED_KEYS.has(key)) return true;
    // A generic yes/no group cannot be a name box however its wording reads, so
    // the label test is skipped for one — that mix-up is what used to refuse
    // demographic answers whose question happened to contain a watched word.
    if (isGenericChoiceGroup(field)) return false;
    return IDENTITY_LABEL_RE.test(String(field?.label ?? ""));
  }

  function recordAnswer(field, { userDriven }) {
    const el = field.el;
    if (!document.contains(el)) return false;

    /**
     * Only an answer a person actually gave.
     *
     * The unsaved list used to fill with the entire form after every fill,
     * because a post-fill pass offered every field that held a value — the
     * profile's, a saved answer's, the model's — as though the applicant had
     * just typed it. Nothing is held now unless something marked this control
     * as edited by hand, which is what the applicant expects to review.
     */
    if (!el.__zapplyUserEdited) return false;

    /**
     * A name is not a saved answer.
     *
     * The guard for this lived in the sweep only, so correcting an autofilled
     * First Name or Email on the page — an ordinary thing to do — offered it as
     * an answer to bank against a question, and reusing it on the next
     * application is both wrong and a privacy problem. These fields are edited
     * in the profile; the check belongs on every path into the queue, not on
     * one of them.
     */
    if (belongsToProfile(field)) return false;

    const answer = String(readValue(field) ?? "").trim();
    if (!answer) return false;
    if (PLACEHOLDER_OPTION_RE.test(answer)) return false;
    if (el.__zapplyLastCaptured === answer) return false;
    if (!userDriven && matchesWritten(el, answer)) return false;

    // This is the re-render-safe provenance guard. The element-local marker can
    // disappear when Workday/Ashby replaces the node, but the short-lived ledger
    // still knows that this exact question+answer came from Zapply.
    if (isKnownProgrammaticAnswer(field, answer)) return false;

    /**
     * An answer Zapply wrote is never the applicant's answer.
     *
     * `__zapplyUserEdited` was the only provenance test, and it is set by an
     * `input` listener as soon as the 1500ms programmatic window lapses. The
     * settle passes that repair a form the page cleared run at 900ms and
     * 2200ms — the "Restored 7 fields" notice — so the second of them writes
     * outside that window, the listener called it typing, and answers the
     * applicant had never touched appeared in the unsaved list. Asking whether
     * the control still holds exactly what we put in it settles provenance
     * without depending on the timing of any event.
     *
     * Exact equality, not the containment `matchesWritten` uses: ticking a
     * second box in a group leaves the first one in the value, and that is a
     * new answer, not our old one.
     */
    if (sameAsWritten(el, answer)) return false;

    /**
     * A drafted answer is held to the stricter test.
     *
     * A model's paragraph is the one thing on the form that was neither the
     * applicant's nor the profile's, and a widget that reflows or trims it
     * would slip past exact equality. Until they change it, it is not theirs.
     */
    if (isDrafted(el) && matchesWritten(el, answer)) return false;

    // readValue reports an empty checkbox group as "No". That is the right
    // reading for a single "I agree" box the person deliberately left clear,
    // but for a group nobody has touched yet it is not an answer at all.
    if (field.kind === "checkbox") {
      const members = groupMembersOf(el);
      const anyTicked = members.some((m) => m.checked === true || m.getAttribute?.("aria-checked") === "true");
      // An unchecked checkbox group is an empty field, not a reusable "No"
      // answer. Never save that empty state back into Saved Answers.
      if (!anyTicked) return false;
    }

    const question = capturedQuestion(field);
    if (!question || question.length > 300) return false;

    el.__zapplyLastCaptured = answer;
    if (!worthSaving(field, answer)) return false;

    /**
     * The choices this question offered, kept whatever markup drew them.
     *
     * `optionTextsFor` alone returns a single entry for a radio group with no
     * `name` attribute, so a saved "choice" answer arrived with no choices
     * beside it and the dashboard had nothing to render as options. The group
     * members are the authority; the helper is merged in for the select and
     * segmented-button cases it handles better.
     */
    let options = [];
    if (field.kind === "select" || field.kind === "radio" || field.kind === "checkbox") {
      const seen = new Set();
      const add = (value) => {
        const text = String(value ?? "").trim().replace(/\s+/g, " ");
        if (!text || seen.has(text.toLowerCase())) return;
        seen.add(text.toLowerCase());
        options.push(text);
      };
      try { (M.optionTextsFor(el) || []).forEach(add); } catch {}
      if (field.kind === "radio" || field.kind === "checkbox") {
        try { groupMembersOf(el).forEach((m) => add(M.radioOptionText?.(m))); } catch {}
      }
      options = options
        .filter((o) => !PLACEHOLDER_OPTION_RE.test(o))
        .filter((o) => o.length <= 200)
        .slice(0, 50);
    }

    clearProgrammaticAnswer(field, answer);
    holdAnswer(field, {
      question: uncontestedQuestion(field, question),
      answer,
      // The control the answer came from, so the popup and the dashboard can
      // both say whether this was a dropdown, a radio group or a text box.
      inputType: field.kind || "text",
      options,
      ats: state.adapter?.key,
      domain: location.hostname,
      source: "user",
    });
    el.classList.remove("zapply-needs-you");
    return true;
  }

  /**
   * Every control being watched, re-read after anything the person does.
   *
   * Listeners alone only ever caught typing. A native <select> fires `change`
   * on itself, but a custom dropdown paints its answer into a button while the
   * click lands on an option in a portal somewhere else in the document, and a
   * radio group fires on whichever member was clicked rather than the one the
   * field was anchored to. All of those went unrecorded, which is why picking a
   * dropdown or radio answer never produced anything to sync.
   */
  const watched = new Map();
  let sweepTimer = null;

  /**
   * When a real person last did something anywhere on this page.
   *
   * The browser marks events it synthesises for page scripts as untrusted, so a
   * trusted event is proof a human is at the keyboard. The sweep needs this
   * because a custom dropdown paints its answer into a button while the click
   * lands on an option in a portal elsewhere in the document — the control that
   * changed never sees an event of its own, so without a page-level signal the
   * only choices were to bank every dropdown or to bank none of them.
   */
  let lastHumanAt = 0;

  /**
   * `isTrusted` is not by itself proof of a person.
   *
   * Text is written with `execCommand("insertText")`, which is what gets a
   * value into Workday's own model — and the *user agent* dispatches the
   * resulting `beforeinput` and `input`, so the browser marks them trusted.
   * Zapply's own fill therefore announced that a human was at the keyboard.
   * When Workday then hydrated and wiped First and Last Name 400ms later, the
   * sweep read the wipe as the applicant clearing the fields, marked them
   * user-owned, and the settle pass refused to restore them — leaving "The
   * field First Name is required" at Next with nothing in the box.
   *
   * An event arriving on a control Zapply is mid-write on is Zapply's.
   */
  const noteHuman = (event) => {
    if (!event?.isTrusted) return;
    try {
      const target = event.target;
      if (target && target.nodeType === 1 && isGroupProgrammatic(target)) return;
    } catch {}
    lastHumanAt = Date.now();
  };
  const HUMAN_WINDOW_MS = 8000;

  /** What this control held the last time we looked, so a change is detectable. */
  function baseline(field) {
    try { return String(readValue(field) ?? "").trim(); } catch { return ""; }
  }

  function sweepWatched() {
    const humanNearby = Date.now() - lastHumanAt < HUMAN_WINDOW_MS;

    for (const [el, field] of watched) {
      if (!document.contains(el)) { watched.delete(el); continue; }

      let current = "";
      try { current = baseline(field); } catch { continue; }

      // Unchanged since the last look: nothing happened here.
      if (current === (el.__zapplyBaselineValue ?? "")) continue;

      // It changed, so re-baseline whatever the verdict below is — otherwise
      // one ignored change is re-examined on every subsequent sweep.
      const previous = el.__zapplyBaselineValue ?? "";
      el.__zapplyBaselineValue = current;

      // Still holding exactly what Zapply wrote: this is the fill landing, not
      // a person answering.
      if (matchesWritten(el, current)) continue;
      if (isGroupProgrammatic(el) && !previous) continue;

      // No trusted event anywhere on the page recently, so nobody was here to
      // make this change — a late-rendering widget or the site's own script.
      if (!humanNearby) continue;

      // Any changed field can be a manual edit, including profile-backed work
      // history/date fields. The earlier profile-owned guard made edits to
      // extension-filled Work Experience, dates, radios and checkboxes vanish
      // from Pending Saved Answers. Provenance is already established by the
      // written-value/programmatic checks above.
      el.__zapplyUserEdited = true;
      try { recordAnswer(field, { userDriven: false }); } catch {}
    }
  }

  function scheduleSweep() {
    clearTimeout(sweepTimer);
    // Long enough for a menu to close and the widget to paint its choice.
    sweepTimer = setTimeout(sweepWatched, 350);
  }

  let sweepStarted = false;
  function startSweep() {
    if (sweepStarted) return;
    sweepStarted = true;
    ["click", "change", "keyup", "focusout"].forEach((type) =>
      document.addEventListener(type, scheduleSweep, true)
    );
    // Separate from scheduleSweep: these establish that a person is present,
    // which the sweep then uses to decide whether a changed value is theirs.
    ["pointerdown", "keydown", "beforeinput", "input", "paste", "cut", "change"].forEach((type) =>
      document.addEventListener(type, noteHuman, true)
    );
  }

  function captureOn(field) {
    if (field.el.__zapplyWatched || field.el.__zapplyGroupWatched) return;
    field.el.__zapplyWatched = true;
    // The whole group answers one question, so no other member may be watched
    // separately — otherwise focusing a second radio queued the same answer
    // twice, once against each element's own bookkeeping.
    groupMembersOf(field.el).forEach((m) => { m.__zapplyGroupWatched = true; });
    watched.set(field.el, field);
    // Whatever the control holds the moment it comes under watch is the
    // starting point. The sweep only reacts to a change from this, so a page
    // that arrives pre-populated queues nothing until someone alters it.
    if (field.el.__zapplyBaselineValue === undefined) {
      field.el.__zapplyBaselineValue = baseline(field);
    }
    startSweep();

    const capture = (event) => {
      // A trusted event is proof a person is acting on this control, so it ends
      // the window that marks the control as ours immediately — otherwise an
      // edit made straight after a fill was dropped for a second and a half.
      /**
       * Our own write is settled before the event is believed.
       *
       * `isTrusted` is not proof of a person here. Committing a radio or
       * checkbox answer calls .click() on the option, and the browser's own
       * activation behaviour then fires `input` and `change` — which the spec
       * marks **trusted**, because the user agent dispatched them. So Zapply's
       * click cleared its own programmatic window, the handler concluded a
       * person had answered, and the answer just replayed out of Saved Answers
       * was offered straight back as a new unsaved one. Asking whether we are
       * mid-write first, and only then believing the event, breaks that loop.
       */
      if (isGroupProgrammatic(field.el)) return;
      if (event?.isTrusted) lastHumanAt = Date.now();

      /**
       * Being present at a field is not answering it.
       *
       * This ran on every blur, so clicking into a box the portal had already
       * filled and clicking away again marked it edited and offered its
       * contents as an answer to save. Tabbing through a form was enough to
       * queue most of it. An edit has to actually change something: the value
       * is compared against what the control held when it came under watch, and
       * that reference is re-taken after each accepted change.
       */
      const current = baseline(field);
      if (current === (field.el.__zapplyBaselineValue ?? "")) return;

      // Once the user changes a field it is user-owned for this session.
      field.el.__zapplyUserEdited = true;
      recordAnswer(field, { userDriven: true });
      field.el.__zapplyBaselineValue = current;
    };

    // A setter marks a control as ours for up to 1.5s so the widget's own
    // trailing events aren't mistaken for typing. A real key press or click is
    // proof the person has taken over, so it ends that window immediately —
    // otherwise an edit made straight after a fill was silently discarded.
    const releaseToUser = (e) => {
      if (!e.isTrusted) return;
      // The whole group, so choosing a different radio with the keyboard or the
      // mouse counts as taking over from the fill however the group is wired.
      releaseGroupToUser(field.el);
    };
    // Any of these can only come from a real person: the browser marks events
    // it synthesises for page scripts as untrusted. A trusted `input` is the
    // one that matters most — typing over an AI draft produces it, and without
    // it that edit was dropped for the first second and a half after a fill.
    // `input` is deliberately absent: activation behaviour fires a *trusted*
    // `input` when Zapply clicks a radio or checkbox, so treating it as proof
    // of a person handed our own write back to the applicant. Everything left
    // here can only come from a real interaction — typing still releases the
    // control immediately through `keydown` and `beforeinput`.
    ["keydown", "pointerdown", "beforeinput", "paste", "cut"].forEach((type) =>
      field.el.addEventListener(type, releaseToUser, true)
    );

    field.el.addEventListener("input", () => {
      if (!isProgrammatic(field.el)) field.el.__zapplyUserEdited = true;
    }, true);
    field.el.addEventListener("blur", capture, true);
    field.el.addEventListener("change", capture);

    // A segmented control answers on a click, and the person may well click the
    // segment that isn't the one we anchored the field to.
    // A widget answers after its menu closes, so the capture has to be delayed
    // — but the delay loses the event, and with it the proof that a person did
    // this. The trusted flag is carried across by hand.
    const deferredCapture = (event, delay) => {
      const trusted = Boolean(event?.isTrusted);
      if (trusted) lastHumanAt = Date.now();
      setTimeout(() => capture(trusted ? { isTrusted: true } : null), delay);
    };

    const segments = M.choiceButtonGroup?.(field.el);
    if (segments?.length) {
      segments.forEach((seg) => {
        seg.addEventListener("pointerdown", releaseToUser, true);
        seg.addEventListener("click", (e) => deferredCapture(e, 250));
      });
    } else if (field.el.tagName === "BUTTON") {
      field.el.addEventListener("click", (e) => deferredCapture(e, 700));
    }

    // Native radio and checkbox groups fire on whichever member was clicked,
    // not on the one this field is anchored to.
    if (field.kind === "radio" || field.kind === "checkbox") {
      try {
        groupMembersOf(field.el).forEach((member) => {
          if (member === field.el) return;
          // Keyboard selection moves through a radio group with arrow keys and
          // never produces a pointer event, so the release has to cover both.
          ["pointerdown", "keydown"].forEach((type) =>
            member.addEventListener(type, releaseToUser, true)
          );
          member.addEventListener("change", capture);
          member.addEventListener("click", (e) => deferredCapture(e, 120));
        });
      } catch {}
    }
  }

  /**
   * Rule keys whose answer belongs to the profile rather than to Saved Answers.
   *
   * Everything else is watched, which is the fix for "I corrected the answer and
   * it never saved". The old rule was `if (field.rule) return` — any field a
   * rule had matched was excluded from capture entirely, so changing a notice
   * period from "2 weeks" to "30 days", or a work-authorisation answer from Yes
   * to No, was never recorded and the stale answer stayed in the dashboard.
   *
   * Identity, contact, history and voluntary-disclosure fields stay out: they
   * are edited in the profile, and copying a name or an EEO answer into a
   * question bank would be both noise and a privacy problem.
   */
  const PROFILE_OWNED_KEYS = new Set([
    "firstName", "lastName", "middleName", "preferredName", "fullName", "signature",
    "dateOfBirth", "email", "emailConfirm",
    "phone", "phoneCountryCode", "phoneType",
    "address", "addressLine2", "city", "state", "zip", "location",
    "linkedin", "github", "portfolio", "twitter",
    "resume", "coverLetter",
    // Repeated history rows are positional — "Company (row 2)" means nothing on
    // the next site — so they are answered from the profile, never banked.
    "currentCompany", "currentTitle", "experienceLocation", "responsibilities",
    "experienceStartDate", "experienceEndDate", "experienceDatePart",
    "experienceStartMonth", "experienceStartYear", "experienceEndMonth", "experienceEndYear",
    "school", "educationLocation", "graduationDate", "educationDatePart",
    "educationStartMonth", "educationStartYear", "educationEndMonth", "educationEndYear",
  ]);

  function watchUnmatched() {
    state.unmatched.forEach(captureOn);
    state.drafted.forEach((el) => {
      const field = state.allFields?.find((f) => f.el === el);
      if (field) captureOn(field);
    });
    (state.allFields ?? []).forEach((field) => {
      if (field.kind === "file") return;
      captureOn(field);
    });
  }

  /**
   * Does a drafted answer have the shape this field will accept?
   *
   * Asked for a LinkedIn profile it has no URL for, the model answers in
   * sentences — "I do not have a LinkedIn profile or social network account" —
   * which is a perfectly sensible reply and completely unusable. Workday
   * rejects it as an invalid URL and the applicant is left holding a validation
   * error they did nothing to cause. A blank is what they wanted anyway.
   */
  function answerFitsFormat(field, answer) {
    const el = field.el;
    const text = String(Array.isArray(answer) ? answer.join(", ") : answer ?? "").trim();
    if (!text) return false;
    const type = (el.getAttribute?.("type") || "").toLowerCase();
    const label = String(field.label ?? "");

    const wantsUrl =
      type === "url" ||
      /\b(url|link|linked-?in|git-?hub|portfolio|website|web\s*site|profile\s*(link|url))\b/i.test(label);
    if (wantsUrl) {
      return /^(https?:\/\/|www\.)\S+$/i.test(text) || /^[\w-]+(\.[\w-]+)+\/\S*$/i.test(text);
    }

    if (type === "email" || /\be-?mail\b/i.test(label)) {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text);
    }

    if (type === "tel" || /\b(phone|mobile|telephone)\b/i.test(label)) {
      return (text.match(/\d/g) || []).length >= 7;
    }

    return true;
  }

  /**
   * Is a drafted answer one of the choices this control actually offers?
   *
   * Free-text fields have nothing to check against, so they always pass.
   */
  function answerFitsOptions(field, answer) {
    const isChoice = field.kind === "select" || field.kind === "radio" || field.kind === "checkbox";
    if (!isChoice) return true;

    let choices = [];
    try { choices = M.optionTextsFor(field.el) || []; } catch {}
    // A remote menu that has not loaded yet offers nothing to compare against;
    // the setter opens it and does its own matching from there.
    if (!choices.length) return true;

    const norm = (x) => {
      try { return M.normalizeChoiceText(String(x)); } catch { return String(x).toLowerCase().trim(); }
    };
    const wanted = Array.isArray(answer) ? answer : [answer];
    const normalised = choices.map(norm).filter(Boolean);

    return wanted.every((one) => {
      const a = norm(one);
      if (!a) return false;
      return normalised.some((b) => a === b || a.includes(b) || b.includes(a));
    });
  }

  /**
   * Offer the answers the applicant gave by hand, and only those.
   *
   * This used to walk every field on the page and offer whatever it held, on
   * the reasoning that an answer is worth keeping whoever produced it. In
   * practice that meant one Fill click filled the unsaved list with the entire
   * form — the profile's own values, replayed saved answers, AI drafts — and
   * buried the handful of answers the applicant had actually chosen. The
   * dropdown, radio and checkbox answers picked by hand are the ones worth
   * reviewing, so those are the ones offered.
   *
   * The values Zapply wrote are not lost by being left out: profile data lives
   * in the profile, and a replayed saved answer is already saved.
   */
  function queueAnswersFromForm() {
    for (const field of state.allFields ?? []) {
      try {
        if (field.kind === "file") continue;
        if (!document.contains(field.el)) continue;
        // The one test that matters: did a person put this here?
        if (!field.el.__zapplyUserEdited) continue;

        const answer = String(readValue(field) ?? "").trim();
        if (!answer) continue;

        // Already saved with exactly this answer — re-queueing it would just be
        // noise in a list meant for reviewing what changed.
        const saved = findSavedAnswer(field);
        if (saved?.exact && String(saved.answer).trim() === answer) continue;

        recordAnswer(field, { userDriven: true });
      } catch {}
    }
  }

  /**
   * Attach the capture listeners without filling anything.
   *
   * These used to be attached only at the end of a fill, so a person who opened
   * an application and simply typed their answers — never pressing Fill — had
   * nothing recorded at all.
   */
  function watchPage() {
    try {
      const adapter = state.adapter ?? (state.adapter = ATS.detect());
      const fields = collectFields(adapter);
      if (!state.allFields?.length) state.allFields = fields;
      else {
        const known = new Set(state.allFields.map((f) => f.el));
        state.allFields.push(...fields.filter((f) => !known.has(f.el)));
      }
      watchUnmatched();
    } catch {}
  }

  /**
   * Anything the person clicks is watched from that moment on.
   *
   * `focusin` is not enough on its own. A great many ATS controls are divs —
   * `role="radio"`, `role="checkbox"`, a react-select combobox — carrying no
   * tabindex, so they can be clicked but never focused and the focus watcher
   * never fired for them. Their answers were only ever picked up if the field
   * happened to be in the one scan done at load, and on a step that rendered
   * later it never was, so answering them produced nothing to save.
   *
   * The click may land on a wrapper, a label, or the tick mark inside an
   * option, so the search runs from the target outwards and then inwards.
   */
  function watchClicks() {
    const CONTROL_SEL =
      "input, select, textarea, [role='radio'], [role='checkbox'], [role='combobox'], [role='listbox'], [role='switch'], [role='option']";

    document.addEventListener("pointerdown", (event) => {
      if (!event.isTrusted) return;
      try {
        const target = event.target;
        if (!target?.closest) return;

        // Outwards: the control itself, or the label/option wrapping the click.
        let el = target.closest(CONTROL_SEL);

        // A <label> commits to the control it names rather than one inside it.
        if (!el) {
          const label = target.closest("label");
          const forId = label?.getAttribute?.("for");
          if (forId) { try { el = document.getElementById(forId); } catch {} }
          if (!el && label) el = label.querySelector(CONTROL_SEL);
        }

        // An option row in a portal belongs to whichever combobox is open.
        if (el?.getAttribute?.("role") === "option") {
          const owner = document.querySelector("[role='combobox'][aria-expanded='true']");
          if (owner) el = owner;
        }

        if (!el) return;
        watchControl(el);
      } catch {}
    }, true);
  }

  /**
   * Bring one control under watch, working out its label and rule first.
   *
   * Shared by the focus and pointer watchers so both apply the same rules about
   * what may be banked — in particular that a profile-owned box is never
   * offered as a saved answer.
   */
  function watchControl(el) {
    if (!el || el.__zapplyWatched || el.__zapplyGroupWatched || el.__zapplyIgnored) return;
    if (!M.isFillable(el)) return;
    if (["submit", "reset", "button", "image", "file"].includes(el.type)) return;
    if (inPageChrome(el)) { el.__zapplyIgnored = true; return; }
    const label = M.deriveLabel(el);
    const rule = M.matchRule(el, label, RULES);
    const field = { el, label, kind: M.fieldKind(el), rule };
    /**
     * Profile-owned fields are not banked as answers. This was opened up in
     * 1.8.0 so hand-corrections could be saved, and that was a mistake: an
     * email address captured off one form is an *answer* to a question whose
     * wording resembles half the contact boxes on the next one, so it came
     * back in the phone field. Contact details and identity belong in the
     * profile, which is the only place they can be stored once and used
     * everywhere without being matched by question text.
     *
     * A Yes/No/decline group is exempt — see isGenericChoiceGroup. Those are
     * questions that merely share a word with a profile rule, and refusing
     * them is what made demographic answers look like they never saved.
     */
    captureOn(field);
  }

  /**
   * Anything the person focuses is watched from that moment on. A single scan
   * can't see fields a step hasn't rendered yet, and focus is the cheapest
   * possible signal that a control is about to be answered.
   */
  function watchOnFocus() {
    document.addEventListener("focusin", (event) => {
      try { watchControl(event.target); } catch {}
    }, true);
  }

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") flushAnswers();
  });
  window.addEventListener("pagehide", flushAnswers);

  /* ================================================================== */
  /*  Submit detection + sync                                            */
  /* ================================================================== */

  function watchSubmit() {
    const report = () => {
      const settings = state.session?.settings ?? {};
      const meta = ATS.readJobMeta(state.adapter ?? ATS.detect());
      const responses = Array.from(state.captured.values());

      flushAnswers();
      const payload = { responses };
      if (settings.trackAutomatically !== false && state.lastRun) {
        payload.application = {
          jobTitle: meta.jobTitle,
          company: meta.company,
          companyDomain: meta.companyDomain,
          location: meta.location,
          url: meta.url,
          ats: meta.ats,
          autofill: {
            fieldsDetected: state.lastRun.detected,
            fieldsFilled: state.lastRun.filled,
            durationMs: state.lastRun.durationMs,
          },
        };
      }
      if (payload.application || responses.length) send({ type: "ZAPPLY_SYNC", payload });
      state.captured.clear();
    };

    document.addEventListener("submit", () => setTimeout(report, 300), true);

    document.addEventListener(
      "click",
      (e) => {
        const btn = e.target?.closest?.('button, input[type="submit"], a[role="button"]');
        if (!btn) return;
        const text = (btn.textContent || btn.value || "").trim().toLowerCase();
        if (/^(submit|submit application|apply|send application|finish|complete)/.test(text)) {
          setTimeout(report, 700);
        }
      },
      true
    );
  }

  /* ================================================================== */
  /*  Visual feedback                                                    */
  /* ================================================================== */

  function flash(el) {
    el.classList.add("zapply-filled");
    setTimeout(() => el.classList.remove("zapply-filled"), 1200);
  }
  function mark(el) {
    el.classList.add("zapply-needs-you");
  }

  const overlay = {
    node: null,
    timer: null,
    ensure() {
      if (this.node?.isConnected) return this.node;
      const el = document.createElement("div");
      el.className = "zapply-pill";
      el.innerHTML = `
        <span class="zapply-pill__dot"></span>
        <span class="zapply-pill__text">
          <span class="zapply-pill__title"></span>
          <span class="zapply-pill__body"></span>
        </span>
        <button class="zapply-pill__stop" type="button">Stop</button>
        <button class="zapply-pill__close" aria-label="Dismiss">&times;</button>`;
      el.querySelector(".zapply-pill__close").addEventListener("click", () => this.hide());
      el.querySelector(".zapply-pill__stop").addEventListener("click", async () => {
        state.stopRequested = true;
        state.manualSessionActive = false;
        await send({ type: "ZAPPLY_STOP" });
        el.querySelector(".zapply-pill__stop").disabled = true;
        el.querySelector(".zapply-pill__stop").textContent = "Stopping…";
      });
      (document.body || document.documentElement).appendChild(el);
      this.node = el;
      return el;
    },
    show({ tone = "busy", title, body, autoHide = false }) {
      const el = this.ensure();
      el.dataset.tone = tone;
      el.querySelector(".zapply-pill__title").textContent = title;
      el.querySelector(".zapply-pill__body").textContent = body ?? "";
      const stop = el.querySelector(".zapply-pill__stop");
      stop.disabled = !state.filling;
      stop.textContent = "Stop";
      stop.hidden = !state.filling;
      el.classList.add("zapply-pill--visible");
      clearTimeout(this.timer);
      // `autoHide` may be a duration in milliseconds or just `true` for the
      // default. It was previously a flag with one hard-coded delay, so a
      // caller asking for three seconds silently got four and a half.
      const delay = typeof autoHide === "number" ? autoHide : autoHide ? 4500 : 0;
      if (delay > 0) this.timer = setTimeout(() => this.hide(), delay);
    },
    hide() {
      this.node?.classList.remove("zapply-pill--visible");
    },
  };

  /* Cross-origin iframe support: many enterprise ATSs embed the application
   * inside a same-page iframe. The content script already runs in all frames;
   * this relay lets the top frame's toolbar command reach child frames. */
  function relayToChildFrames(type) {
    if (window.top !== window) return;
    document.querySelectorAll("iframe, frame").forEach((frame) => {
      try { frame.contentWindow?.postMessage({ source: "zapply", type }, "*"); } catch {}
    });
  }

  window.addEventListener("message", (event) => {
    if (event?.data?.source !== "zapply") return;
    if (event.data.type === "ZAPPLY_RUN" && window.top !== window) run({ manual: true });
    if (event.data.type === "ZAPPLY_STOP") {
      state.stopRequested = true;
      state.manualSessionActive = false;
    }
  });

  /* ================================================================== */
  /*  Boot                                                               */
  /* ================================================================== */

  async function loadSession(force = false) {
    const res = await send({ type: "ZAPPLY_GET_SESSION", force });
    if (res?.ok) state.session = res.data;
    return state.session;
  }

  /**
   * Re-scan as the page grows.
   *
   * `watchPage()` used to run exactly once, at load. Everything rendered after
   * that — the next step of a Workday application, an "Add another" section, a
   * demographics block that hydrates a second late — was invisible to it, and
   * the only remaining way to attach a watcher was focus, which never fires for
   * a div-based control. So on a multi-step form the applicant answered a whole
   * page of questions and the popup showed nothing to save.
   *
   * Debounced, and only woken by mutations that actually add an element, so a
   * page animating its own DOM does not turn this into a scan loop.
   */
  const RESCAN_DELAY_MS = 500;
  /**
   * A floor on how often the page is actually re-scanned.
   *
   * Debouncing alone is not enough on a portal that mutates continuously —
   * Workday repaints on scroll — because the quiet period never arrives and
   * the scans stack up. `collectFields` walks the whole document, so this has
   * to stay cheap or it is a jank source on every page the extension runs on.
   */
  const RESCAN_MIN_GAP_MS = 1500;
  let rescanTimer = null;
  let rescanObserver = null;
  let lastRescanAt = 0;

  function scheduleRescan() {
    clearTimeout(rescanTimer);
    const since = Date.now() - lastRescanAt;
    const wait = Math.max(RESCAN_DELAY_MS, RESCAN_MIN_GAP_MS - since);
    rescanTimer = setTimeout(rescanForFields, wait);
  }

  function watchForNewFields() {
    if (rescanObserver) return;
    try {
      rescanObserver = new MutationObserver((records) => {
        for (const record of records) {
          for (const node of record.addedNodes ?? []) {
            if (node.nodeType !== 1) continue;
            scheduleRescan();
            return;
          }
        }
      });
      rescanObserver.observe(document.documentElement, { childList: true, subtree: true });
    } catch {}
  }

  function rescanForFields() {
    lastRescanAt = Date.now();
    /**
     * The application-page test is re-run here, not only at load.
     *
     * It counts the text boxes on the page, and a form that renders from
     * JavaScript has none of them at DOMContentLoaded. The whole content script
     * disengaged on exactly the modern applications it is most needed on, and
     * nothing the applicant typed was ever recorded. Once engaged it stays
     * engaged; this only ever turns capture on.
     */
    if (!state.engaged) {
      if (!isApplicationPage()) return;
      engage();
      return;
    }
    try { watchPage(); } catch {}
  }

  /** Attach every watcher, once, as soon as this looks like an application. */
  function engage() {
    if (state.engaged) return;
    state.engaged = true;
    watchSubmit();
    // Answers typed by hand are recorded from now on, whether or not a fill is
    // ever run on this page.
    watchOnFocus();
    watchClicks();
    watchPage();
    watchValidation();
    startSweep();
  }

  async function boot() {
    state.adapter = ATS.detect();

    const session = await loadSession();
    if (!session?.profile) return;
    if (isExcluded(session.settings)) return;

    // Watch for the form arriving even if it is not here yet.
    watchForNewFields();
    if (isApplicationPage()) engage();
    if (!state.engaged) return;

    const meta = ATS.readJobMeta(state.adapter);
    const dupe = await send({
      type: "ZAPPLY_CHECK",
      payload: { url: meta.url, jobTitle: meta.jobTitle, company: meta.company },
    });

    if (dupe?.ok && dupe.data?.duplicate) {
      state.duplicate = dupe.data.application;
      const when = new Date(state.duplicate.appliedAt).toLocaleDateString(undefined, { month: "short", day: "numeric" });
      overlay.show({
        tone: "warn",
        title: "You already applied to this",
        body: `Sent ${when} — currently "${state.duplicate.stage}". Click the Zapply icon to fill it anyway.`,
      });
      return; // manual fill still works via the popup
    }

    /**
     * Nothing is filled here. Ever.
     *
     * `boot()` used to honour a "Fill as soon as a form loads" setting with one
     * pass. One pass per load is still one pass per *reload* — and a Workday
     * application reloads itself constantly: a validation error, a step change,
     * a tab switched back to. Every one of those restarted a fill over answers
     * the applicant had already corrected by hand, which is the behaviour
     * reported as "when we refresh the tab it fills the form again".
     *
     * The setting is ignored rather than merely defaulted off, so an account
     * that switched it on in the past does not keep the old behaviour. Filling
     * now has exactly one trigger: the Fill button (or its keyboard shortcut).
     */
    if (state.duplicate) return;
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }

  // Test hook. Only ever attached when a harness sets the flag before the
  // content script loads, so nothing is exposed to real pages.
  if (window.__ZAPPLY_TEST === true) {
    window.__zapply = { run, collectFields, planField, state, M, RULES };
  }
})();
